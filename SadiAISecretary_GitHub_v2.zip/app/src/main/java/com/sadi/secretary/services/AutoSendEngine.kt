package com.sadi.secretary.services

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — AutoSendEngine.kt                  ║
// ║       Phase 08 · Auto Send Queue Processor                   ║
// ║                                                              ║
// ║  Screen on হলে → queue check → approved replies send        ║
// ║  Delay support, window change tracking                       ║
// ╚══════════════════════════════════════════════════════════════╝

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.sadi.secretary.data.repository.MessageRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutoSendEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: MessageRepository
) {
    companion object {
        private const val TAG = "SadiAutoSendEngine"
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isProcessing = false
    private var currentWindow: String? = null

    // ══════════════════════════════════════════════════════════
    // SCREEN ON — process pending queue
    // ══════════════════════════════════════════════════════════
    init {
        // Screen on broadcast listen করো
        val filter = IntentFilter(Intent.ACTION_SCREEN_ON)
        context.registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                Log.d(TAG, "Screen on — checking send queue")
                scope.launch { processSendQueue() }
            }
        }, filter)
    }

    // ══════════════════════════════════════════════════════════
    // PROCESS QUEUE
    // ══════════════════════════════════════════════════════════
    suspend fun processSendQueue() {
        if (isProcessing) return
        isProcessing = true

        try {
            val approvedReplies = repository.getApprovedReplies()
            if (approvedReplies.isEmpty()) {
                Log.d(TAG, "Queue empty — nothing to send")
                return
            }

            Log.d(TAG, "${approvedReplies.size} approved replies to send")

            val service = SadiAccessibilityService.instance
            if (service == null) {
                Log.w(TAG, "Accessibility service not connected — cannot auto-send")
                return
            }

            approvedReplies.forEach { reply ->
                // Delay check — scheduled time এসেছে কিনা
                val scheduledTime = reply.scheduledSendAt ?: 0L
                if (scheduledTime > System.currentTimeMillis()) {
                    Log.d(TAG, "Reply ${reply.id} scheduled for later — skipping")
                    return@forEach
                }

                Log.d(TAG, "Sending reply ${reply.id} to ${reply.contactName}")

                // Send করো
                var sendSuccess = false
                val job = scope.launch {
                    service.sendMessage(reply) { success ->
                        sendSuccess = success
                    }
                }
                job.join()

                if (sendSuccess) {
                    repository.markSent(reply.id)
                    repository.markReplied(reply.messageId)
                    Log.d(TAG, "✅ Sent reply ${reply.id}")
                } else {
                    Log.e(TAG, "❌ Failed to send reply ${reply.id}")
                }

                // Multiple replies এর মধ্যে delay
                delay(2000)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Queue processing error: ${e.message}", e)
        } finally {
            isProcessing = false
        }
    }

    // Window change track করা
    fun onWindowChanged(packageName: String?, root: AccessibilityNodeInfo?) {
        currentWindow = packageName
    }

    // Manually trigger করার জন্য (approve করার সাথে সাথে)
    fun triggerSend() {
        scope.launch { processSendQueue() }
    }
}
