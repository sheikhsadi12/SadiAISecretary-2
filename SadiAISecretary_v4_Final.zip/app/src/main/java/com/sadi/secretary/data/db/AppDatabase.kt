package com.sadi.secretary.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ── ENTITIES ──────────────────────────────────────────────────

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val senderName: String,
    val senderApp: String,
    val messageText: String,
    val isGroup: Boolean = false,
    val groupName: String? = null,
    val timestamp: Long,
    val isReplied: Boolean = false,
    val detectedEmotion: String = "NEUTRAL",
    val packageName: String = ""
)

@Entity(tableName = "contacts")
data class ContactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val app: String,
    val senderId: String,
    val relation: String = "FRIEND",
    val pronoun: String = "তুমি",
    val style: String = "CASUAL",
    val autoSendEnabled: Boolean = false,
    val priority: Int = 3,
    val replyDelaySeconds: Int = 30,
    val isRestricted: Boolean = false,
    val isStealth: Boolean = false
)

@Entity(tableName = "memory")
data class MemoryEntity(
    @PrimaryKey val contactId: Long,
    val lastEmotion: String = "NEUTRAL",
    val lastTopic: String? = null,
    val lastMessageTime: Long = 0,
    val conversationSummary: String? = null,
    val messageCount: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reply_queue")
data class ReplyQueueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val messageId: Long,
    val contactName: String,
    val contactApp: String,
    val originalMessage: String,
    val aiReply: String,
    val status: String = "PENDING",
    val createdAt: Long = System.currentTimeMillis(),
    val scheduledSendAt: Long? = null
)

// ── DAOs ──────────────────────────────────────────────────────

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: MessageEntity): Long

    @Query("SELECT * FROM messages ORDER BY timestamp DESC LIMIT 50")
    fun getAllMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE senderName = :name ORDER BY timestamp DESC LIMIT 10")
    suspend fun getMessagesBySender(name: String): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE isReplied = 0 ORDER BY timestamp DESC")
    fun getUnrepliedMessages(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE isReplied = 1 ORDER BY timestamp DESC LIMIT 100")
    suspend fun getRepliedMessages(): List<MessageEntity>

    @Query("UPDATE messages SET isReplied = 1 WHERE id = :id")
    suspend fun markAsReplied(id: Long)

    @Query("UPDATE messages SET detectedEmotion = :emotion WHERE id = :id")
    suspend fun updateEmotion(id: Long, emotion: String)

    @Query("DELETE FROM messages WHERE timestamp < :before")
    suspend fun deleteOldMessages(before: Long)
}

@Dao
interface ContactDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(contact: ContactEntity): Long

    @Update
    suspend fun update(contact: ContactEntity)

    @Query("SELECT * FROM contacts ORDER BY priority DESC")
    fun getAllContacts(): Flow<List<ContactEntity>>

    @Query("SELECT * FROM contacts WHERE name = :name AND app = :app LIMIT 1")
    suspend fun getContact(name: String, app: String): ContactEntity?

    @Query("SELECT * FROM contacts WHERE autoSendEnabled = 1")
    suspend fun getAutoSendContacts(): List<ContactEntity>

    @Query("DELETE FROM contacts WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(memory: MemoryEntity)

    @Query("SELECT * FROM memory WHERE contactId = :contactId")
    suspend fun getMemory(contactId: Long): MemoryEntity?

    @Query("UPDATE memory SET lastEmotion = :emotion, updatedAt = :time WHERE contactId = :contactId")
    suspend fun updateEmotion(contactId: Long, emotion: String, time: Long = System.currentTimeMillis())

    @Query("UPDATE memory SET conversationSummary = :summary, messageCount = :count WHERE contactId = :contactId")
    suspend fun updateSummary(contactId: Long, summary: String, count: Int)
}

@Dao
interface ReplyQueueDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reply: ReplyQueueEntity): Long

    @Query("SELECT * FROM reply_queue WHERE status = 'PENDING' ORDER BY createdAt ASC")
    fun getPendingReplies(): Flow<List<ReplyQueueEntity>>

    @Query("SELECT * FROM reply_queue WHERE status = 'APPROVED' ORDER BY scheduledSendAt ASC")
    suspend fun getApprovedReplies(): List<ReplyQueueEntity>

    @Query("UPDATE reply_queue SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Query("UPDATE reply_queue SET aiReply = :newReply WHERE id = :id")
    suspend fun updateReply(id: Long, newReply: String)

    @Query("SELECT COUNT(*) FROM reply_queue WHERE status = 'PENDING'")
    fun getPendingCount(): Flow<Int>

    @Query("DELETE FROM reply_queue WHERE status IN ('SENT', 'REJECTED') AND createdAt < :before")
    suspend fun cleanOld(before: Long)
}

// ── DATABASE ──────────────────────────────────────────────────

@Database(
    entities = [MessageEntity::class, ContactEntity::class, MemoryEntity::class, ReplyQueueEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun contactDao(): ContactDao
    abstract fun memoryDao(): MemoryDao
    abstract fun replyQueueDao(): ReplyQueueDao
}
