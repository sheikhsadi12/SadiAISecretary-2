package com.sadi.secretary.style

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun StyleScreen(viewModel: StyleViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    val config = uiState.styleConfig
    val scrollState = rememberScrollState()

    uiState.toastMessage?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(2000)
            viewModel.clearToast()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(scrollState)) {

            Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Style Imitation ✍️", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("AI তোমার মতো লিখবে", fontSize = 12.sp, color = Color(0xFF64748B))
                    }
                    TextButton(onClick = { viewModel.reAnalyze() }) {
                        Text("Re-analyze", color = Color(0xFF00D4FF), fontSize = 12.sp)
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionLabel2("DETECTED STYLE")
            StyleSummaryCard2(config)

            Spacer(Modifier.height(16.dp))
            SectionLabel2("EMOJI FREQUENCY")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EmojiFreq.values().forEach { freq ->
                    val sel = config.emojiFrequency == freq
                    FilterChip(selected = sel, onClick = { viewModel.setEmojiFreq(freq) },
                        label = { Text(freq.displayName, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFFCD34D).copy(alpha = 0.15f),
                            selectedLabelColor = Color(0xFFFCD34D),
                            containerColor = Color(0xFF111827), labelColor = Color(0xFF64748B)
                        ),
                        border = FilterChipDefaults.filterChipBorder(enabled = true, selected = sel,
                            selectedBorderColor = Color(0xFFFCD34D), borderColor = Color(0xFF1E2D45))
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionLabel2("SENTENCE LENGTH")
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SentenceStyle.values().forEach { style ->
                    val sel = config.sentenceStyle == style
                    FilterChip(selected = sel, onClick = { viewModel.setSentenceStyle(style) },
                        label = { Text(style.displayName, fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF00D4FF).copy(alpha = 0.15f),
                            selectedLabelColor = Color(0xFF00D4FF),
                            containerColor = Color(0xFF111827), labelColor = Color(0xFF64748B)
                        ),
                        border = FilterChipDefaults.filterChipBorder(enabled = true, selected = sel,
                            selectedBorderColor = Color(0xFF00D4FF), borderColor = Color(0xFF1E2D45))
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
            SectionLabel2("তোমার SLANG WORDS")
            SlangEditor2(config.usesSlang, { viewModel.addSlang(it) }, { viewModel.removeSlang(it) })

            Spacer(Modifier.height(40.dp))
        }

        uiState.toastMessage?.let { msg ->
            Surface(modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                shape = RoundedCornerShape(24.dp), color = Color(0xFF1E2D45)) {
                Text(msg, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                    color = Color(0xFF00D4FF), fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun StyleSummaryCard2(config: StyleConfig) {
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Detected Style", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF94A3B8))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF00D4FF).copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, Color(0xFF00D4FF).copy(alpha = 0.3f))) {
                    Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("~${config.avgWordCount.toInt()}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00D4FF))
                        Text("Words/msg", fontSize = 10.sp, color = Color(0xFF475569))
                    }
                }
                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFFCD34D).copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, Color(0xFFFCD34D).copy(alpha = 0.3f))) {
                    Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(config.emojiFrequency.displayName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCD34D))
                        Text("Emoji", fontSize = 10.sp, color = Color(0xFF475569))
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            val banglaPercent = (config.banglaRatio * 100).toInt()
            Text("Language: ~${banglaPercent}% Bangla · ~${100 - banglaPercent}% English",
                fontSize = 12.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
private fun SlangEditor2(slangList: List<String>, onAdd: (String) -> Unit, onRemove: (String) -> Unit) {
    var newSlang by remember { mutableStateOf("") }
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        // Show chips in rows of 4
        slangList.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 6.dp)) {
                row.forEach { word ->
                    InputChip(selected = false, onClick = {},
                        label = { Text(word, fontSize = 12.sp) },
                        trailingIcon = {
                            Icon(Icons.Default.Close, null,
                                modifier = Modifier.size(14.dp).clickable { onRemove(word) },
                                tint = Color(0xFF64748B))
                        },
                        colors = InputChipDefaults.inputChipColors(containerColor = Color(0xFF111827), labelColor = Color(0xFF94A3B8)),
                        border = InputChipDefaults.inputChipBorder(enabled = true, selected = false, borderColor = Color(0xFF1E2D45))
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = newSlang, onValueChange = { newSlang = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("নতুন word...", color = Color(0xFF334155), fontSize = 13.sp) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF00D4FF),
                    unfocusedBorderColor = Color(0xFF1E2D45), focusedTextColor = Color.White,
                    unfocusedTextColor = Color(0xFF94A3B8)),
                shape = RoundedCornerShape(10.dp), singleLine = true)
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { if (newSlang.isNotBlank()) { onAdd(newSlang.trim()); newSlang = "" } },
                modifier = Modifier.background(Color(0xFF0A1628), RoundedCornerShape(10.dp))) {
                Icon(Icons.Default.Add, null, tint = Color(0xFF00D4FF))
            }
        }
    }
}

@Composable
private fun SectionLabel2(text: String) {
    Text(text = text, fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
}
