package com.sadi.secretary.faithtime

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — FaithTimeViewModel.kt              ║
// ║       Phase 07 · Faith + Time ViewModel                      ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FaithTimeUiState(
    val activeModes: ActiveModes = ActiveModes(),
    val currentTimeContext: TimeContext = TimeContext.NORMAL,
    val scheduleConfig: ScheduleConfig = ScheduleConfig(),
    val isAiActiveNow: Boolean = true,
    val quickReplySuggestions: List<String> = emptyList(),
    val toastMessage: String? = null
)

@HiltViewModel
class FaithTimeViewModel @Inject constructor(
    private val faithTimeManager: FaithTimeManager,
    private val scheduleManager: ScheduleManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(FaithTimeUiState())
    val uiState: StateFlow<FaithTimeUiState> = _uiState.asStateFlow()

    // In-memory modes (Phase 10 এ DataStore এ persist হবে)
    private var currentModes = ActiveModes()

    init {
        loadInitialState()
    }

    private fun loadInitialState() {
        viewModelScope.launch {
            val timeContext = faithTimeManager.getCurrentTimeContext()
            val suggestions = faithTimeManager.getQuickReplySuggestions(timeContext)
            val isActive = scheduleManager.isAiActiveNow()

            scheduleManager.scheduleFlow.collect { schedule ->
                _uiState.update {
                    it.copy(
                        currentTimeContext     = timeContext,
                        quickReplySuggestions  = suggestions,
                        scheduleConfig         = schedule,
                        isAiActiveNow          = isActive
                    )
                }
            }
        }
    }

    fun updateModes(modes: ActiveModes) {
        currentModes = modes
        _uiState.update { it.copy(activeModes = modes, toastMessage = "Settings updated ✅") }
    }

    fun updateSchedule(config: ScheduleConfig) {
        viewModelScope.launch {
            scheduleManager.saveSchedule(config)
            val isActive = scheduleManager.isAiActiveNow()
            _uiState.update {
                it.copy(
                    scheduleConfig = config,
                    isAiActiveNow  = isActive,
                    toastMessage   = if (config.isScheduleEnabled) "Schedule saved ✅" else "Schedule disabled"
                )
            }
        }
    }

    // ReplyEngine কে current modes দেওয়ার জন্য
    fun getCurrentModes(): ActiveModes = currentModes

    fun clearToast() = _uiState.update { it.copy(toastMessage = null) }
}
