package com.sadi.secretary.services

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — SadiForegroundService.kt          ║
// ║        Phase 00 · Always-On Background Service               ║
// ║                                                              ║
// ║  এই service app কে সবসময় alive রাখে                         ║
// ║  MIUI battery killer থেকে বাঁচায়                            ║
// ║  একটা silent notification সবসময় দেখায়: "Sadi AI চলছে 🟢"   ║
// ╚══════════════════════════════════════════════════════════════╝

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.sadi.secretary.R
import com.sadi.secretary.SadiApp
import com.sadi.secretary.ui.MainActivity

class SadiForegroundService : Service() {

    companion object {
        private const val TAG = "SadiForegroundService"
        private const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.sadi.secretary.START"
        const val ACTION_STOP  = "com.sadi.secretary.STOP"

        // Service status (other parts of app জানতে পারবে)
        var isRunning = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Sadi Foreground Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        when (intent?.action) {

            ACTION_START -> {
                Log.d(TAG, "Starting Sadi AI Secretary service...")
                startForeground(NOTIFICATION_ID, buildNotification("চলছে 🟢", "সব message monitor হচ্ছে"))
                isRunning = true
            }

            ACTION_STOP -> {
                Log.d(TAG, "Stopping Sadi AI Secretary service...")
                isRunning = false
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }

        // START_STICKY → service kill হলে Android নিজেই restart করবে
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        Log.d(TAG, "Sadi service destroyed")
    }

    // ──────────────────────────────────────────────────────────
    // Persistent notification তৈরি করা
    // এই notification app কে alive রাখে
    // ──────────────────────────────────────────────────────────
    private fun buildNotification(title: String, message: String): Notification {

        // Click করলে MainActivity খুলবে
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Stop button
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, SadiForegroundService::class.java).apply {
                action = ACTION_STOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, SadiApp.CHANNEL_FOREGROUND)
            .setContentTitle("Sadi AI Secretary $title")
            .setContentText(message)
            .setSmallIcon(R.drawable.ic_notification)   // res/drawable তে add করতে হবে
            .setContentIntent(openAppIntent)
            .setOngoing(true)           // Swipe করে dismiss করা যাবে না
            .setSilent(true)            // কোনো sound/vibration নেই
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, "বন্ধ করো", stopIntent)
            .build()
    }

    // ──────────────────────────────────────────────────────────
    // Notification update করা (status change হলে)
    // ──────────────────────────────────────────────────────────
    fun updateNotification(title: String, message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(title, message))
    }
}
