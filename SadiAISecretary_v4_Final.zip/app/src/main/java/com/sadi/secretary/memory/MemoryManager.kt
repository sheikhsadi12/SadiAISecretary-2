package com.sadi.secretary.memory

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — MemoryManager.kt                  ║
// ║        Phase 05 · Long-Term Memory System                    ║
// ║                                                              ║
// ║  প্রতিটা contact এর জন্য মনে রাখে:                           ║
// ║    → Last emotion + mood trend                               ║
// ║    → Last topic                                              ║
// ║    → Conversation summary (AI generated)                     ║
// ║    → Important life events (exam, travel, illness...)        ║
// ║                                                              ║
// ║  Context example:                                            ║
// ║    "তুমি তো গত সপ্তাহে exam নিয়ে tension এ ছিলে..."          ║
// ╚══════════════════════════════════════════════════════════════╝

import android.util.Log
import com.sadi.secretary.ai.*
import com.sadi.secretary.data.db.MemoryEntity
import com.sadi.secretary.data.db.MessageEntity
import com.sadi.secretary.data.repository.MessageRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MemoryManager @Inject constructor(
    private val repository: MessageRepository,
    private val emotionDetector: EmotionDetector,
    private val clientFactory: AiClientFactory
) {
    companion object {
        private const val TAG = "SadiMemory"
        private const val SUMMARY_EVERY_N = 5   // প্রতি ৫ message এ summary
    }

    // ══════════════════════════════════════════════════════════
    // MEMORY UPDATE — নতুন message আসলে call হয়
    // ══════════════════════════════════════════════════════════
    suspend fun onNewMessage(
        contactId: Long,
        contactName: String,
        message: MessageEntity
    ) {
        try {
            // Memory init করো যদি না থাকে
            repository.initMemoryIfNeeded(contactId)
            val memory = repository.getMemory(contactId) ?: return

            // Fast emotion detect
            val fastEmotion = emotionDetector.detectFast(message.messageText)

            // Topic extract করো
            val topic = extractTopic(message.messageText)

            // Memory update করো
            val updatedMemory = memory.copy(
                lastEmotion     = fastEmotion.name,
                lastTopic       = topic ?: memory.lastTopic,
                lastMessageTime = message.timestamp,
                messageCount    = memory.messageCount + 1,
                updatedAt       = System.currentTimeMillis()
            )
            repository.saveMemoryDirectly(updatedMemory)

            Log.d(TAG, "Memory updated for $contactName — emotion: ${fastEmotion.name}, topic: $topic")

            // Summary generate করো (প্রতি N message এ)
            if (updatedMemory.messageCount % SUMMARY_EVERY_N == 0) {
                generateSummary(contactId, contactName, updatedMemory.messageCount)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Memory update error: ${e.message}")
        }
    }

    // ══════════════════════════════════════════════════════════
    // BUILD CONTEXT STRING — prompt এ inject হবে
    // ══════════════════════════════════════════════════════════
    suspend fun buildContextString(
        contactId: Long,
        contactName: String
    ): String {
        val memory = repository.getMemory(contactId) ?: return ""
        val recentMessages = repository.getRecentMessages(contactName)

        return buildString {
            // Emotion context
            if (memory.lastEmotion != "NEUTRAL") {
                val emotion = emotionDetector.fromString(memory.lastEmotion)
                appendLine("${contactName} এর সাম্প্রতিক mood: ${emotion.emoji} ${emotion.displayName}")
            }

            // Last topic
            memory.lastTopic?.let { topic ->
                appendLine("আগের কথা হচ্ছিল: $topic")
            }

            // Conversation summary
            memory.conversationSummary?.let { summary ->
                if (summary.isNotBlank()) {
                    appendLine("Summary: $summary")
                }
            }

            // Recent 3 messages
            if (recentMessages.isNotEmpty()) {
                appendLine("\nসাম্প্রতিক কথা:")
                recentMessages.takeLast(3).forEach { msg ->
                    val who = if (msg.isReplied) "Sadi" else contactName
                    appendLine("$who: ${msg.messageText}")
                }
            }
        }.trim()
    }

    // ══════════════════════════════════════════════════════════
    // GENERATE SUMMARY — AI দিয়ে summary বানানো
    // ══════════════════════════════════════════════════════════
    private suspend fun generateSummary(
        contactId: Long,
        contactName: String,
        messageCount: Int
    ) {
        try {
            val messages = repository.getRecentMessages(contactName)
            if (messages.size < 3) return

            val conversationText = messages.takeLast(10).joinToString("\n") { msg ->
                val who = if (msg.isReplied) "Sadi" else contactName
                "$who: ${msg.messageText}"
            }

            val prompt = """
                এই conversation এর একটা ছোট summary দাও (২-৩ line এ)।
                কী topic, কার mood কেমন ছিল mention করো।
                Bangla তে লেখো। শুধু summary text দাও।
                
                Conversation:
                $conversationText
            """.trimIndent()

            val client = clientFactory.getActiveClient()
            val response = client.generate(
                AiRequest(
                    systemPrompt = "তুমি একটা conversation summarizer।",
                    messages     = listOf(AiMessage("user", prompt)),
                    maxTokens    = 120,
                    temperature  = 0.3
                )
            )

            if (response.isSuccess && response.text.isNotBlank()) {
                repository.updateSummary(contactId, response.text, messageCount)
                Log.d(TAG, "Summary saved for contactId: $contactId")
            }

        } catch (e: Exception) {
            Log.w(TAG, "Summary generation failed: ${e.message}")
        }
    }

    // ══════════════════════════════════════════════════════════
    // TOPIC EXTRACTION — keyword দেখে topic বোঝার চেষ্টা
    // ══════════════════════════════════════════════════════════
    private fun extractTopic(text: String): String? {
        val lower = text.lowercase()
        return when {
            EXAM_KEYWORDS.any { lower.contains(it) }     -> "পরীক্ষা / পড়াশোনা"
            HEALTH_KEYWORDS.any { lower.contains(it) }   -> "স্বাস্থ্য / অসুস্থতা"
            TRAVEL_KEYWORDS.any { lower.contains(it) }   -> "ভ্রমণ / বাইরে যাওয়া"
            WORK_KEYWORDS.any { lower.contains(it) }     -> "কাজ / পড়াশোনা"
            FAMILY_KEYWORDS.any { lower.contains(it) }   -> "পরিবার"
            RELIGION_KEYWORDS.any { lower.contains(it) } -> "দ্বীন / ইসলাম"
            else -> null
        }
    }

    private val EXAM_KEYWORDS   = setOf("exam", "পরীক্ষা", "result", "রেজাল্ট", "study", "পড়া", "hsc", "ssc", "admission")
    private val HEALTH_KEYWORDS = setOf("sick", "অসুস্থ", "জ্বর", "ব্যথা", "doctor", "ডাক্তার", "hospital", "medicine")
    private val TRAVEL_KEYWORDS = setOf("travel", "বেড়াতে", "যাচ্ছি", "আসছি", "ট্রেন", "বাস", "গ্রাম", "ঢাকা")
    private val WORK_KEYWORDS   = setOf("কাজ", "job", "project", "deadline", "assignment", "class", "ক্লাস")
    private val FAMILY_KEYWORDS = setOf("amma", "ammu", "abbu", "baba", "ভাই", "আপু", "পরিবার", "বাসা")
    private val RELIGION_KEYWORDS = setOf("namaz", "নামাজ", "quran", "কুরআন", "dua", "দোয়া", "ramadan", "রমজান", "eid", "ঈদ")
}
