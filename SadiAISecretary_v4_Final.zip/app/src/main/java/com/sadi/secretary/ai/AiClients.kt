package com.sadi.secretary.ai

// ╔══════════════════════════════════════════════════════════════╗
// ║         SADI AI SECRETARY — AiClients.kt                     ║
// ║         Phase 02 · All Provider Implementations              ║
// ╚══════════════════════════════════════════════════════════════╝

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

private const val TAG = "SadiAiClient"
private const val TIMEOUT = 30_000  // 30 seconds

// ══════════════════════════════════════════════════════════════
// HELPER — HTTP POST করার common function
// ══════════════════════════════════════════════════════════════
private suspend fun httpPost(
    url: String,
    headers: Map<String, String>,
    body: String
): Pair<Int, String> = withContext(Dispatchers.IO) {
    val conn = URL(url).openConnection() as HttpURLConnection
    try {
        conn.requestMethod = "POST"
        conn.connectTimeout = TIMEOUT
        conn.readTimeout = TIMEOUT
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }

        OutputStreamWriter(conn.outputStream).use { it.write(body) }

        val code = conn.responseCode
        val response = if (code in 200..299) {
            conn.inputStream.bufferedReader().readText()
        } else {
            conn.errorStream?.bufferedReader()?.readText() ?: "Unknown error"
        }
        Pair(code, response)
    } finally {
        conn.disconnect()
    }
}

// ══════════════════════════════════════════════════════════════
// 1️⃣  CLAUDE CLIENT (Anthropic)
// ══════════════════════════════════════════════════════════════
class ClaudeClient(private val apiKey: String) : BaseAiClient {

    override val provider = AiProvider.CLAUDE

    override fun isConfigured() = apiKey.isNotBlank()

    override suspend fun generate(request: AiRequest): AiResponse {
        return try {
            // Messages array (system ছাড়া)
            val messagesArray = JSONArray().apply {
                request.messages.filter { it.role != "system" }.forEach { msg ->
                    put(JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    })
                }
            }

            val body = JSONObject().apply {
                put("model", AiProvider.CLAUDE.defaultModel)
                put("max_tokens", request.maxTokens)
                put("system", request.systemPrompt)
                put("messages", messagesArray)
            }.toString()

            val (code, response) = httpPost(
                url = "https://api.anthropic.com/v1/messages",
                headers = mapOf(
                    "x-api-key"         to apiKey,
                    "anthropic-version" to "2023-06-01"
                ),
                body = body
            )

            if (code == 200) {
                val json = JSONObject(response)
                val text = json
                    .getJSONArray("content")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()
                AiResponse(text = text, provider = provider, isSuccess = true)
            } else {
                Log.e(TAG, "Claude error $code: $response")
                AiResponse(text = "", provider = provider, isSuccess = false, error = "Claude API error: $code")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Claude exception: ${e.message}")
            AiResponse(text = "", provider = provider, isSuccess = false, error = e.message)
        }
    }
}

// ══════════════════════════════════════════════════════════════
// 2️⃣  GEMINI CLIENT (Google)
// ══════════════════════════════════════════════════════════════
class GeminiClient(private val apiKey: String) : BaseAiClient {

    override val provider = AiProvider.GEMINI

    override fun isConfigured() = apiKey.isNotBlank()

    override suspend fun generate(request: AiRequest): AiResponse {
        return try {
            // Gemini এ system prompt আলাদাভাবে যায় না
            // প্রথম user message এ inject করি
            val fullUserMessage = "${request.systemPrompt}\n\n${request.messages.lastOrNull { it.role == "user" }?.content ?: ""}"

            val contentsArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", fullUserMessage))
                    })
                })
            }

            val body = JSONObject().apply {
                put("contents", contentsArray)
                put("generationConfig", JSONObject().apply {
                    put("maxOutputTokens", request.maxTokens)
                    put("temperature", request.temperature)
                })
            }.toString()

            val model = AiProvider.GEMINI.defaultModel
            val (code, response) = httpPost(
                url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey",
                headers = emptyMap(),
                body = body
            )

            if (code == 200) {
                val json = JSONObject(response)
                val text = json
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                    .trim()
                AiResponse(text = text, provider = provider, isSuccess = true)
            } else {
                Log.e(TAG, "Gemini error $code: $response")
                AiResponse(text = "", provider = provider, isSuccess = false, error = "Gemini API error: $code")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini exception: ${e.message}")
            AiResponse(text = "", provider = provider, isSuccess = false, error = e.message)
        }
    }
}

// ══════════════════════════════════════════════════════════════
// 3️⃣  OPENAI CLIENT (GPT-4o)
// ══════════════════════════════════════════════════════════════
class OpenAiClient(private val apiKey: String) : BaseAiClient {

    override val provider = AiProvider.OPENAI

    override fun isConfigured() = apiKey.isNotBlank()

    override suspend fun generate(request: AiRequest): AiResponse {
        return try {
            val messagesArray = JSONArray().apply {
                // System message প্রথমে
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", request.systemPrompt)
                })
                // বাকি messages
                request.messages.filter { it.role != "system" }.forEach { msg ->
                    put(JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    })
                }
            }

            val body = JSONObject().apply {
                put("model", AiProvider.OPENAI.defaultModel)
                put("messages", messagesArray)
                put("max_tokens", request.maxTokens)
                put("temperature", request.temperature)
            }.toString()

            val (code, response) = httpPost(
                url = "https://api.openai.com/v1/chat/completions",
                headers = mapOf("Authorization" to "Bearer $apiKey"),
                body = body
            )

            if (code == 200) {
                val json = JSONObject(response)
                val text = json
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()
                AiResponse(text = text, provider = provider, isSuccess = true)
            } else {
                Log.e(TAG, "OpenAI error $code: $response")
                AiResponse(text = "", provider = provider, isSuccess = false, error = "OpenAI API error: $code")
            }
        } catch (e: Exception) {
            Log.e(TAG, "OpenAI exception: ${e.message}")
            AiResponse(text = "", provider = provider, isSuccess = false, error = e.message)
        }
    }
}

// ══════════════════════════════════════════════════════════════
// 4️⃣  GROQ CLIENT (LLaMA-3 — Ultrafast + Free)
// ══════════════════════════════════════════════════════════════
class GroqClient(private val apiKey: String) : BaseAiClient {

    override val provider = AiProvider.GROQ

    override fun isConfigured() = apiKey.isNotBlank()

    override suspend fun generate(request: AiRequest): AiResponse {
        return try {
            // Groq OpenAI-compatible API use করে
            val messagesArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "system")
                    put("content", request.systemPrompt)
                })
                request.messages.filter { it.role != "system" }.forEach { msg ->
                    put(JSONObject().apply {
                        put("role", msg.role)
                        put("content", msg.content)
                    })
                }
            }

            val body = JSONObject().apply {
                put("model", AiProvider.GROQ.defaultModel)
                put("messages", messagesArray)
                put("max_tokens", request.maxTokens)
                put("temperature", request.temperature)
            }.toString()

            val (code, response) = httpPost(
                url = "https://api.groq.com/openai/v1/chat/completions",
                headers = mapOf("Authorization" to "Bearer $apiKey"),
                body = body
            )

            if (code == 200) {
                val json = JSONObject(response)
                val text = json
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                    .trim()
                AiResponse(text = text, provider = provider, isSuccess = true)
            } else {
                Log.e(TAG, "Groq error $code: $response")
                AiResponse(text = "", provider = provider, isSuccess = false, error = "Groq API error: $code")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Groq exception: ${e.message}")
            AiResponse(text = "", provider = provider, isSuccess = false, error = e.message)
        }
    }
}
