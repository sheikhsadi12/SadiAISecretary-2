package com.sadi.secretary.services

// ╔══════════════════════════════════════════════════════════════╗
// ║      SADI AI SECRETARY — SadiAccessibilityService.kt         ║
// ║      Phase 08 · Auto Send Engine                             ║
// ║                                                              ║
// ║  FLOW:                                                       ║
// ║    App open → Contact find → Text box click                  ║
// ║    → Human-like typing → Send button click                   ║
// ║                                                              ║
// ║  SUPPORTED:                                                  ║
// ║    → Messenger  (com.facebook.orca)                          ║
// ║    → Telegram   (org.telegram.messenger)                     ║
// ╚══════════════════════════════════════════════════════════════╝

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.sadi.secretary.data.db.ReplyQueueEntity
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject
import kotlin.random.Random

@AndroidEntryPoint
class SadiAccessibilityService : AccessibilityService() {

    @Inject lateinit var autoSendEngine: AutoSendEngine

    private val handler = Handler(Looper.getMainLooper())
    private val scope   = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        private const val TAG = "SadiAutoSend"
        var instance: SadiAccessibilityService? = null
            private set

        // ── Messenger node IDs ─────────────────────────────────
        private val MESSENGER_COMPOSE_IDS = listOf(
            "com.facebook.orca:id/composer_input",
            "com.facebook.orca:id/message_edit_text",
            "com.facebook.orca:id/input_text"
        )
        private val MESSENGER_SEND_IDS = listOf(
            "com.facebook.orca:id/send_button",
            "com.facebook.orca:id/action_button"
        )

        // ── Telegram node IDs ──────────────────────────────────
        private val TELEGRAM_COMPOSE_IDS = listOf(
            "org.telegram.messenger:id/chatActivityEnterView",
            "org.telegram.messenger:id/message_text",
            "org.telegram.messenger:id/editText"
        )
        private val TELEGRAM_SEND_IDS = listOf(
            "org.telegram.messenger:id/chat_compose_button",
            "org.telegram.messenger:id/send_button"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "✅ Accessibility Service connected")

        // Service configure করো
        serviceInfo = serviceInfo.apply {
            flags = flags or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                    AccessibilityServiceInfo.FLAG_REQUEST_ENHANCED_WEB_ACCESSIBILITY
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        // AutoSendEngine কে notify করো window change হলে
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                autoSendEngine.onWindowChanged(event.packageName?.toString(), rootInActiveWindow)
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        scope.cancel()
        Log.d(TAG, "Accessibility Service destroyed")
    }

    // ══════════════════════════════════════════════════════════
    // SEND MESSAGE — main function
    // ══════════════════════════════════════════════════════════
    fun sendMessage(reply: ReplyQueueEntity, onComplete: (Boolean) -> Unit) {
        scope.launch {
            try {
                Log.d(TAG, "Auto-sending to ${reply.contactName} via ${reply.contactApp}")

                // Step 1: App open করো
                val opened = openApp(reply.contactApp)
                if (!opened) {
                    Log.e(TAG, "Failed to open app: ${reply.contactApp}")
                    onComplete(false)
                    return@launch
                }

                // App load হওয়ার জন্য wait
                delay(2000)

                // Step 2: Text box খুঁজে পাও
                val textBox = findTextBox(reply.contactApp)
                if (textBox == null) {
                    Log.e(TAG, "Text box not found")
                    onComplete(false)
                    return@launch
                }

                // Step 3: Text box focus করো
                textBox.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                delay(500)

                // Step 4: Human-like typing
                typeHumanLike(textBox, reply.aiReply)

                // Step 5: Send button খুঁজে click করো
                delay(300)
                val sent = clickSendButton(reply.contactApp)

                if (sent) {
                    Log.d(TAG, "✅ Message sent successfully to ${reply.contactName}")
                    onComplete(true)
                } else {
                    Log.e(TAG, "Send button not found")
                    onComplete(false)
                }

            } catch (e: Exception) {
                Log.e(TAG, "Auto-send error: ${e.message}", e)
                onComplete(false)
            }
        }
    }

    // ══════════════════════════════════════════════════════════
    // OPEN APP
    // ══════════════════════════════════════════════════════════
    private fun openApp(app: String): Boolean {
        return try {
            val pkg = when (app) {
                "messenger" -> "com.facebook.orca"
                "telegram"  -> "org.telegram.messenger"
                else -> return false
            }
            val intent = packageManager.getLaunchIntentForPackage(pkg)
                ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Open app error: ${e.message}")
            false
        }
    }

    // ══════════════════════════════════════════════════════════
    // FIND TEXT BOX
    // ══════════════════════════════════════════════════════════
    private suspend fun findTextBox(app: String): AccessibilityNodeInfo? {
        val ids = when (app) {
            "messenger" -> MESSENGER_COMPOSE_IDS
            "telegram"  -> TELEGRAM_COMPOSE_IDS
            else        -> emptyList()
        }

        // কয়েকবার চেষ্টা করো (UI load হতে সময় লাগে)
        repeat(5) { attempt ->
            val root = rootInActiveWindow ?: return@repeat
            for (id in ids) {
                val nodes = root.findAccessibilityNodeInfosByViewId(id)
                if (nodes.isNotEmpty()) {
                    return nodes[0]
                }
            }
            // Text input field যেকোনো ধরনের খোঁজো
            val editNode = findNodeByClass(root, "android.widget.EditText")
            if (editNode != null) return editNode

            delay(800)
        }
        return null
    }

    // ══════════════════════════════════════════════════════════
    // HUMAN-LIKE TYPING
    // প্রতিটা character আলাদা আলাদা delay দিয়ে type করে
    // যেন মানুষ type করছে মনে হয়
    // ══════════════════════════════════════════════════════════
    private suspend fun typeHumanLike(node: AccessibilityNodeInfo, text: String) {
        // পুরো text একসাথে set করো (faster approach)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

        // Human simulation delay (মনে হবে type করছে)
        val typingDelay = (text.length * Random.nextLong(40, 80)).coerceIn(500, 3000)
        delay(typingDelay)

        Log.d(TAG, "Typed: \"$text\" (simulated ${typingDelay}ms)")
    }

    // ══════════════════════════════════════════════════════════
    // CLICK SEND BUTTON
    // ══════════════════════════════════════════════════════════
    private suspend fun clickSendButton(app: String): Boolean {
        val ids = when (app) {
            "messenger" -> MESSENGER_SEND_IDS
            "telegram"  -> TELEGRAM_SEND_IDS
            else        -> emptyList()
        }

        repeat(3) {
            val root = rootInActiveWindow ?: return@repeat
            for (id in ids) {
                val nodes = root.findAccessibilityNodeInfosByViewId(id)
                if (nodes.isNotEmpty()) {
                    nodes[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    return true
                }
            }
            // Content description দিয়ে খোঁজো
            val sendNode = findNodeByDescription(root, listOf("send", "Send", "পাঠাও"))
            if (sendNode != null) {
                sendNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                return true
            }
            delay(500)
        }
        return false
    }

    // ══════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════
    private fun findNodeByClass(root: AccessibilityNodeInfo, className: String): AccessibilityNodeInfo? {
        if (root.className?.toString() == className) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findNodeByClass(child, className)
            if (found != null) return found
        }
        return null
    }

    private fun findNodeByDescription(root: AccessibilityNodeInfo, descriptions: List<String>): AccessibilityNodeInfo? {
        val desc = root.contentDescription?.toString()?.lowercase()
        if (desc != null && descriptions.any { desc.contains(it.lowercase()) }) return root
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findNodeByDescription(child, descriptions)
            if (found != null) return found
        }
        return null
    }
}
