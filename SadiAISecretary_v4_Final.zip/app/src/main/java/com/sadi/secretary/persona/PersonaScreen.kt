package com.sadi.secretary.persona

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — PersonaScreen.kt                  ║
// ║        Phase 04 · Persona Settings UI                        ║
// ║                                                              ║
// ║  Contact list → tap → full persona editor                    ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sadi.secretary.data.db.ContactEntity

@Composable
fun PersonaScreen(
    viewModel: PersonaViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    var showEditor by remember { mutableStateOf(false) }

    uiState.toastMessage?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(2000)
            viewModel.clearToast()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {

        if (showEditor && uiState.selectedContact != null) {
            // Persona Editor
            PersonaEditorScreen(
                contact  = uiState.selectedContact!!,
                viewModel = viewModel,
                onBack   = { showEditor = false }
            )
        } else {
            // Contact List
            Column(modifier = Modifier.fillMaxSize()) {

                // Header
                Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Persona System 🎭", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("প্রতিটা contact এর জন্য আলাদা tone", fontSize = 12.sp, color = Color(0xFF64748B))
                    }
                }

                if (uiState.contacts.isEmpty()) {
                    // Empty state
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("👥", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("এখনো কোনো contact নেই", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("Message আসলে automatically যোগ হবে", fontSize = 12.sp, color = Color(0xFF475569), modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(uiState.contacts) { contact ->
                            ContactPersonaCard(
                                contact = contact,
                                onClick = {
                                    viewModel.selectContact(contact)
                                    showEditor = true
                                }
                            )
                        }
                    }
                }
            }
        }

        // Toast
        uiState.toastMessage?.let { msg ->
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF1E2D45)
            ) {
                Text(msg, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp), color = Color(0xFF00D4FF), fontSize = 13.sp)
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// CONTACT CARD in list
// ══════════════════════════════════════════════════════════════
@Composable
private fun ContactPersonaCard(contact: ContactEntity, onClick: () -> Unit) {
    val relation = try { Relation.valueOf(contact.relation) } catch (e: Exception) { Relation.UNKNOWN }
    val appColor = if (contact.app == "telegram") Color(0xFF26A5E4) else Color(0xFF0084FF)

    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar
            Box(
                modifier = Modifier.size(44.dp).clip(CircleShape)
                    .background(Color(0xFF1E2D45)),
                contentAlignment = Alignment.Center
            ) {
                Text(contact.name.take(1).uppercase(), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00D4FF))
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(contact.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(contact.app, fontSize = 11.sp, color = appColor)
                    Text(" · ", fontSize = 11.sp, color = Color(0xFF334155))
                    Text("${relation.emoji} ${relation.displayName}", fontSize = 11.sp, color = Color(0xFF64748B))
                    Text(" · ", fontSize = 11.sp, color = Color(0xFF334155))
                    Text(contact.pronoun, fontSize = 11.sp, color = Color(0xFF64748B))
                }
            }

            // Auto-send indicator
            if (contact.autoSendEnabled) {
                Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFF064E3B)) {
                    Text("AUTO", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 9.sp, color = Color(0xFF34D399), fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF334155))
        }
    }
}

// ══════════════════════════════════════════════════════════════
// PERSONA EDITOR SCREEN
// ══════════════════════════════════════════════════════════════
@Composable
private fun PersonaEditorScreen(
    contact: ContactEntity,
    viewModel: PersonaViewModel,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()
    var currentContact by remember { mutableStateOf(contact) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(scrollState)
    ) {
        // Header with back
        Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, null, tint = Color(0xFF00D4FF))
                }
                Column {
                    Text(contact.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Persona edit করো", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ── Relation Selector ──────────────────────────────────
        SectionTitle("Relation")
        LazyRowSelector(
            options = Relation.values().toList(),
            selected = try { Relation.valueOf(currentContact.relation) } catch (e: Exception) { Relation.UNKNOWN },
            onSelect = { relation ->
                currentContact = currentContact.copy(
                    relation = relation.name,
                    pronoun  = relation.defaultPronoun,
                    style    = relation.defaultStyle
                )
                viewModel.updateRelation(currentContact, relation)
            },
            label = { "${it.emoji} ${it.displayName}" },
            selectedColor = Color(0xFF7C3AED)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // ── Pronoun Selector ───────────────────────────────────
        SectionTitle("Pronoun")
        val pronouns = listOf("তুই", "তুমি", "আপনি")
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            pronouns.forEach { pronoun ->
                val isSelected = currentContact.pronoun == pronoun
                FilterChip(
                    selected = isSelected,
                    onClick = {
                        currentContact = currentContact.copy(pronoun = pronoun)
                        viewModel.updatePronoun(currentContact, pronoun)
                    },
                    label = { Text(pronoun, fontSize = 13.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF1A0A2E),
                        selectedLabelColor     = Color(0xFFA78BFA),
                        containerColor         = Color(0xFF111827),
                        labelColor             = Color(0xFF64748B)
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        selectedBorderColor = Color(0xFF7C3AED),
                        borderColor = Color(0xFF1E2D45)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // ── Style Selector ─────────────────────────────────────
        SectionTitle("Reply Style")
        Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Style.values().forEach { style ->
                val isSelected = currentContact.style == style.name
                Card(
                    modifier = Modifier.fillMaxWidth().clickable {
                        currentContact = currentContact.copy(style = style.name)
                        viewModel.updateStyle(currentContact, style)
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) Color(0xFF0A1628) else Color(0xFF111827)
                    ),
                    border = BorderStroke(1.dp, if (isSelected) Color(0xFF00D4FF) else Color(0xFF1E2D45))
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = isSelected,
                            onClick  = null,
                            colors   = RadioButtonDefaults.colors(selectedColor = Color(0xFF00D4FF), unselectedColor = Color(0xFF475569))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(style.displayName, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (isSelected) Color.White else Color(0xFF94A3B8))
                            Text(style.description, fontSize = 11.sp, color = Color(0xFF475569))
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // ── Auto Send + Delay ──────────────────────────────────
        SectionTitle("Auto Send")
        Card(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
            border = BorderStroke(1.dp, Color(0xFF1E2D45))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto Send", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
                        Text("Approve না করেই automatically send হবে", fontSize = 12.sp, color = Color(0xFF475569))
                    }
                    Switch(
                        checked  = currentContact.autoSendEnabled,
                        onCheckedChange = { enabled ->
                            currentContact = currentContact.copy(autoSendEnabled = enabled)
                            viewModel.updateAutoSend(currentContact, enabled)
                        },
                        colors = SwitchDefaults.colors(
                            checkedTrackColor   = Color(0xFF34D399).copy(alpha = 0.8f),
                            uncheckedTrackColor = Color(0xFF1E2D45)
                        )
                    )
                }

                if (currentContact.autoSendEnabled) {
                    Divider(color = Color(0xFF1E2D45), modifier = Modifier.padding(vertical = 12.dp))
                    Text("Reply Delay", fontSize = 13.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(8.dp))

                    val delayOptions = listOf(
                        0 to "Instant",
                        30 to "30 sec",
                        60 to "1 min",
                        120 to "2 min",
                        300 to "5 min"
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        delayOptions.forEach { (secs, label) ->
                            val isSelected = currentContact.replyDelaySeconds == secs
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    currentContact = currentContact.copy(replyDelaySeconds = secs)
                                    viewModel.updateDelay(currentContact, secs)
                                },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF064E3B),
                                    selectedLabelColor     = Color(0xFF34D399),
                                    containerColor         = Color(0xFF0D1422),
                                    labelColor             = Color(0xFF64748B)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true, selected = isSelected,
                                    selectedBorderColor = Color(0xFF34D399),
                                    borderColor = Color(0xFF1E2D45)
                                )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // ── Restrict ───────────────────────────────────────────
        Card(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (currentContact.isRestricted) Color(0xFF1A0505) else Color(0xFF111827)
            ),
            border = BorderStroke(1.dp, if (currentContact.isRestricted) Color(0xFF7F1D1D) else Color(0xFF1E2D45))
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Restrict Contact", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
                    Text("এই contact এর message এ AI reply করবে না", fontSize = 12.sp, color = Color(0xFF475569))
                }
                Switch(
                    checked = currentContact.isRestricted,
                    onCheckedChange = { restricted ->
                        currentContact = currentContact.copy(isRestricted = restricted)
                        viewModel.updateRestricted(currentContact, restricted)
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor   = Color(0xFFEF4444).copy(alpha = 0.7f),
                        uncheckedTrackColor = Color(0xFF1E2D45)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════
@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title.uppercase(),
        fontSize = 10.sp,
        color = Color(0xFF64748B),
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}

@Composable
private fun <T> LazyRowSelector(
    options: List<T>,
    selected: T,
    onSelect: (T) -> Unit,
    label: (T) -> String,
    selectedColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            val isSelected = option == selected
            FilterChip(
                selected = isSelected,
                onClick  = { onSelect(option) },
                label    = { Text(label(option), fontSize = 12.sp) },
                colors   = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = selectedColor.copy(alpha = 0.2f),
                    selectedLabelColor     = Color(0xFFA78BFA),
                    containerColor         = Color(0xFF111827),
                    labelColor             = Color(0xFF64748B)
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true, selected = isSelected,
                    selectedBorderColor = selectedColor,
                    borderColor = Color(0xFF1E2D45)
                )
            )
        }
    }
}
