package com.sadi.secretary.services

import android.content.Context
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.sadi.secretary.data.repository.MessageRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutoSendEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: MessageRepository
) {
    companion object {
        private const val TAG = "SadiAutoSendEngine"
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var isProcessing = false

    suspend fun processSendQueue() {
        if (isProcessing) return
        isProcessing = true
        try {
            val approvedReplies = repository.getApprovedReplies()
            if (approvedReplies.isEmpty()) return

            val service = SadiAccessibilityService.instance
            if (service == null) {
                Log.w(TAG, "Accessibility service not connected")
                return
            }

            approvedReplies.forEach { reply ->
                val scheduledTime = reply.scheduledSendAt ?: 0L
                if (scheduledTime > System.currentTimeMillis()) return@forEach

                var sendSuccess = false
                service.sendMessage(reply) { success -> sendSuccess = success }

                if (sendSuccess) {
                    repository.markSent(reply.id)
                    repository.markReplied(reply.messageId)
                    Log.d(TAG, "✅ Sent reply ${reply.id}")
                }
                delay(2000)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Queue processing error: ${e.message}", e)
        } finally {
            isProcessing = false
        }
    }

    fun onWindowChanged(packageName: String?, root: AccessibilityNodeInfo?) {}

    fun triggerSend() {
        scope.launch { processSendQueue() }
    }
}
