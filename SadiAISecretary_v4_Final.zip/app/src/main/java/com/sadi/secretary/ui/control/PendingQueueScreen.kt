package com.sadi.secretary.ui.control

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — PendingQueueScreen.kt              ║
// ║       Phase 03 · Main Control UI                             ║
// ║                                                              ║
// ║  এই screen এ দেখাবে:                                         ║
// ║    → সব pending AI replies                                   ║
// ║    → ✅ Send / ✏️ Edit / ❌ Reject buttons                    ║
// ║    → কার কাছ থেকে কী message এসেছে                           ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sadi.secretary.data.db.ReplyQueueEntity
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun PendingQueueScreen(
    viewModel: ControlViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    // Toast message দেখানো
    uiState.toastMessage?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(2500)
            viewModel.clearToast()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C14))
    ) {

        Column(modifier = Modifier.fillMaxSize()) {

            // ── Header ─────────────────────────────────────────
            QueueHeader(pendingCount = uiState.pendingCount)

            // ── Content ────────────────────────────────────────
            if (uiState.pendingReplies.isEmpty()) {
                EmptyQueueView()
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(
                        items = uiState.pendingReplies,
                        key = { it.id }
                    ) { reply ->
                        AnimatedVisibility(
                            visible = true,
                            enter = slideInVertically() + fadeIn(),
                            exit = slideOutHorizontally() + fadeOut()
                        ) {
                            ReplyCard(
                                reply    = reply,
                                onSend   = { viewModel.approveReply(reply.id) },
                                onEdit   = { newText -> viewModel.editReply(reply.id, newText) },
                                onReject = { viewModel.rejectReply(reply.id) }
                            )
                        }
                    }
                }
            }
        }

        // ── Toast ───────────────────────────────────────────────
        uiState.toastMessage?.let { msg ->
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF1E2D45)
            ) {
                Text(
                    text = msg,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                    color = Color(0xFF00D4FF),
                    fontSize = 13.sp
                )
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// HEADER
// ══════════════════════════════════════════════════════════════
@Composable
private fun QueueHeader(pendingCount: Int) {
    Surface(
        color = Color(0xFF0D1422),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Pending Replies",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = if (pendingCount == 0) "সব clear ✅"
                           else "$pendingCount টা reply তোমার approval এর অপেক্ষায়",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B),
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            if (pendingCount > 0) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF1A0A2E)
                ) {
                    Text(
                        text = "$pendingCount",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        color = Color(0xFFA78BFA),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// REPLY CARD — main component
// ══════════════════════════════════════════════════════════════
@Composable
private fun ReplyCard(
    reply: ReplyQueueEntity,
    onSend: () -> Unit,
    onEdit: (String) -> Unit,
    onReject: () -> Unit
) {
    var showEditDialog by remember { mutableStateOf(false) }

    // App color
    val appColor = when (reply.contactApp) {
        "messenger" -> Color(0xFF0084FF)
        "telegram"  -> Color(0xFF26A5E4)
        else        -> Color(0xFF00D4FF)
    }
    val appIcon = when (reply.contactApp) {
        "messenger" -> "💬"
        "telegram"  -> "✈️"
        else        -> "📩"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // ── Sender info ────────────────────────────────────
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // App badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = appColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = appIcon,
                        modifier = Modifier.padding(6.dp),
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = reply.contactName,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp
                    )
                    Text(
                        text = reply.contactApp,
                        fontSize = 11.sp,
                        color = appColor
                    )
                }

                // Time
                Text(
                    text = formatTime(reply.createdAt),
                    fontSize = 11.sp,
                    color = Color(0xFF475569)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ── Original message ───────────────────────────────
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0D1422),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "RECEIVED",
                        fontSize = 9.sp,
                        color = Color(0xFF475569),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = reply.originalMessage,
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ── AI Reply ───────────────────────────────────────
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF0A1628),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, Color(0xFF00D4FF).copy(alpha = 0.2f))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "AI REPLY",
                        fontSize = 9.sp,
                        color = Color(0xFF00D4FF),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = reply.aiReply,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ── Action Buttons ─────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // ✅ SEND
                Button(
                    onClick = onSend,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF064E3B)
                    )
                ) {
                    Icon(
                        Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFF34D399)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("পাঠাও", color = Color(0xFF34D399), fontSize = 13.sp)
                }

                // ✏️ EDIT
                OutlinedButton(
                    onClick = { showEditDialog = true },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFF92400E))
                ) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFFFCD34D)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit", color = Color(0xFFFCD34D), fontSize = 13.sp)
                }

                // ❌ REJECT
                OutlinedButton(
                    onClick = onReject,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFF7F1D1D))
                ) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFFFCA5A5)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("বাদ", color = Color(0xFFFCA5A5), fontSize = 13.sp)
                }
            }
        }
    }

    // Edit Dialog
    if (showEditDialog) {
        EditReplyDialog(
            currentText = reply.aiReply,
            onConfirm = { newText ->
                onEdit(newText)
                showEditDialog = false
            },
            onDismiss = { showEditDialog = false }
        )
    }
}

// ══════════════════════════════════════════════════════════════
// EDIT DIALOG
// ══════════════════════════════════════════════════════════════
@Composable
private fun EditReplyDialog(
    currentText: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var editedText by remember { mutableStateOf(currentText) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF111827),
        titleContentColor = Color.White,
        title = {
            Text("Reply edit করো ✏️", fontWeight = FontWeight.Bold)
        },
        text = {
            OutlinedTextField(
                value = editedText,
                onValueChange = { editedText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor   = Color(0xFF00D4FF),
                    unfocusedBorderColor = Color(0xFF1E2D45),
                    focusedTextColor     = Color.White,
                    unfocusedTextColor   = Color(0xFF94A3B8),
                    cursorColor          = Color(0xFF00D4FF)
                ),
                maxLines = 5
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(editedText) }) {
                Text("Send করো ✅", color = Color(0xFF34D399))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color(0xFF64748B))
            }
        }
    )
}

// ══════════════════════════════════════════════════════════════
// EMPTY STATE
// ══════════════════════════════════════════════════════════════
@Composable
private fun EmptyQueueView() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "✅", fontSize = 48.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "সব clear!",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "নতুন message আসলে এখানে দেখাবে",
                fontSize = 13.sp,
                color = Color(0xFF475569),
                modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════
private fun formatTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
