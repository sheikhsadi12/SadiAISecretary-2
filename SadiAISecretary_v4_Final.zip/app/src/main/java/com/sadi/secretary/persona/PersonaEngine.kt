package com.sadi.secretary.persona

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — PersonaEngine.kt                  ║
// ║        Phase 04 · Persona System Core                        ║
// ║                                                              ║
// ║  প্রতিটা contact = আলাদা tone, pronoun, style                ║
// ║                                                              ║
// ║  Examples:                                                   ║
// ║    Amma    → FAMILY   → তুমি  → RESPECTFUL                   ║
// ║    Rafi    → FRIEND   → তুই   → CASUAL                       ║
// ║    Sir     → TEACHER  → আপনি  → FORMAL                       ║
// ║    Crush   → LOVE     → তুমি  → ROMANTIC                     ║
// ╚══════════════════════════════════════════════════════════════╝

import com.sadi.secretary.data.db.ContactEntity
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════════════════════════
// ENUMS
// ══════════════════════════════════════════════════════════════

enum class Relation(
    val displayName: String,
    val emoji: String,
    val defaultPronoun: String,
    val defaultStyle: String
) {
    FRIEND   ("বন্ধু",    "👫", "তুই",   "CASUAL"),
    FAMILY   ("পরিবার",  "❤️", "তুমি",  "RESPECTFUL"),
    TEACHER  ("শিক্ষক",  "📚", "আপনি",  "FORMAL"),
    LOVE     ("Special", "💝", "তুমি",  "ROMANTIC"),
    COLLEAGUE("Colleague","💼", "তুমি",  "FORMAL"),
    UNKNOWN  ("অজানা",   "👤", "তুমি",  "CASUAL")
}

enum class Style(
    val displayName: String,
    val description: String
) {
    CASUAL      ("Casual",      "Chill, Banglish, emoji ok"),
    FORMAL      ("Formal",      "Respectful, proper tone"),
    ROMANTIC    ("Warm",        "Caring, gentle, sweet"),
    RESPECTFUL  ("Respectful",  "Warm কিন্তু mannered")
}

// ══════════════════════════════════════════════════════════════
// PERSONA ENGINE
// ══════════════════════════════════════════════════════════════
@Singleton
class PersonaEngine @Inject constructor() {

    // Contact এর persona থেকে prompt rules বানাও
    fun buildPersonaRules(contact: ContactEntity): String {
        val relation = try {
            Relation.valueOf(contact.relation)
        } catch (e: Exception) { Relation.UNKNOWN }

        val style = try {
            Style.valueOf(contact.style)
        } catch (e: Exception) { Style.CASUAL }

        return buildString {
            appendLine("## ${contact.name} এর জন্য Persona Rules:")
            appendLine("Relation : ${relation.displayName} ${relation.emoji}")
            appendLine("Pronoun  : ${contact.pronoun} (সবসময় এই pronoun ব্যবহার করবে)")
            appendLine("Style    : ${style.displayName} — ${style.description}")
            appendLine()
            appendLine(getRelationSpecificRules(relation))
        }
    }

    // Relation অনুযায়ী specific rules
    private fun getRelationSpecificRules(relation: Relation): String {
        return when (relation) {

            Relation.FRIEND -> """
                Rules (Friend):
                - একদম chill থাকো, bro/vai বলতে পারো
                - Jokes করতে পারো, light mood রাখো
                - Short reply দাও — paragraphs না
                - Emoji freely use করো
                - "yaar", "bhai", "bro" — এসব natural
            """.trimIndent()

            Relation.FAMILY -> """
                Rules (Family):
                - Warm, caring tone — family তে যেভাবে কথা বলো
                - Respectful কিন্তু loving
                - চিন্তা express করো naturally
                - দরকারে বলো "আচ্ছা মা/আব্বু, পরে কথা হবে ইনশাআল্লাহ"
                - কখনো রুক্ষ বা cold না
            """.trimIndent()

            Relation.TEACHER -> """
                Rules (Teacher/Sir/Ma'am):
                - সম্পূর্ণ respectful — আপনি pronoun
                - Formal Bangla — Banglish কম
                - সংক্ষিপ্ত এবং to-the-point
                - "জি স্যার", "জি ম্যাম" ব্যবহার করো
                - কখনো casual না
            """.trimIndent()

            Relation.LOVE -> """
                Rules (Special Someone):
                - Gentle, warm, caring tone
                - মনোযোগ দিয়ে respond করো
                - তাদের mood বুঝে reply দাও
                - Sweet কিন্তু over-the-top না
                - Natural এবং genuine থাকো
            """.trimIndent()

            Relation.COLLEAGUE -> """
                Rules (Colleague):
                - Professional কিন্তু friendly
                - Formal tone, তুমি/আপনি বরং আপনি নিরাপদ
                - Work related হলে clear এবং concise
                - Small talk এ casual হতে পারো একটু
            """.trimIndent()

            Relation.UNKNOWN -> """
                Rules (Unknown):
                - Neutral, polite tone
                - তুমি pronoun safe option
                - Context দেখে adjust করো
            """.trimIndent()
        }
    }

    // Default persona suggest করো নাম দেখে
    // (যখন নতুন contact প্রথমবার আসে)
    fun suggestPersona(name: String): Pair<Relation, String> {
        val lowerName = name.lowercase()
        return when {
            lowerName.contains("amma")  ||
            lowerName.contains("ammu")  ||
            lowerName.contains("mama")  ||
            lowerName.contains("abbu")  ||
            lowerName.contains("baba")  ||
            lowerName.contains("dadi")  ||
            lowerName.contains("nana")  -> Pair(Relation.FAMILY, "তুমি")

            lowerName.contains("sir")   ||
            lowerName.contains("ma'am") ||
            lowerName.contains("madam") ||
            lowerName.contains("teacher") -> Pair(Relation.TEACHER, "আপনি")

            else -> Pair(Relation.FRIEND, "তুই")
        }
    }
}
