package com.sadi.secretary.ui.settings

// ╔══════════════════════════════════════════════════════════════╗
// ║      SADI AI SECRETARY — ApiSettingsScreen.kt                ║
// ║      Phase 03 · API Keys + Provider Selection                ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sadi.secretary.ai.AiProvider

@Composable
fun ApiSettingsScreen() {
    val scrollState = rememberScrollState()

    // State for each provider's key
    val apiKeys = remember {
        mutableStateMapOf(
            AiProvider.CLAUDE to "",
            AiProvider.GEMINI to "",
            AiProvider.OPENAI to "",
            AiProvider.GROQ   to ""
        )
    }
    var selectedProvider by remember { mutableStateOf(AiProvider.CLAUDE) }
    var savedMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C14))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // Header
            Surface(
                color = Color(0xFF0D1422),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Settings ⚙️", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("API Keys + Provider Selection", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Provider Selection
            Text(
                text = "ACTIVE PROVIDER",
                fontSize = 10.sp,
                color = Color(0xFF64748B),
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )

            AiProvider.values().forEach { provider ->
                ProviderSelectCard(
                    provider = provider,
                    isSelected = selectedProvider == provider,
                    hasKey = apiKeys[provider]?.isNotBlank() == true,
                    onSelect = { selectedProvider = provider }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // API Key inputs
            Text(
                text = "API KEYS",
                fontSize = 10.sp,
                color = Color(0xFF64748B),
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )

            AiProvider.values().forEach { provider ->
                ApiKeyInput(
                    provider = provider,
                    value = apiKeys[provider] ?: "",
                    onValueChange = { apiKeys[provider] = it },
                    onSave = {
                        // TODO: AiSettingsManager.saveApiKey(provider, it)
                        savedMessage = "${provider.displayName} key saved ✅"
                    }
                )
            }

            // Groq free note
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1628)),
                border = BorderStroke(1.dp, Color(0xFF1E3A5F))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text("💡", fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            "Groq একদম Free!",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF7DD3FC)
                        )
                        Text(
                            "console.groq.com থেকে free API key নাও। LLaMA-3 model অনেক fast এবং Bangla বোঝে।",
                            fontSize = 12.sp,
                            color = Color(0xFF475569),
                            modifier = Modifier.padding(top = 3.dp),
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }

        // Save toast
        savedMessage?.let { msg ->
            LaunchedEffect(msg) {
                kotlinx.coroutines.delay(2500)
                savedMessage = null
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF064E3B)
            ) {
                Text(
                    text = msg,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                    color = Color(0xFF34D399),
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun ProviderSelectCard(
    provider: AiProvider,
    isSelected: Boolean,
    hasKey: Boolean,
    onSelect: () -> Unit
) {
    val borderColor = if (isSelected) Color(0xFF00D4FF) else Color(0xFF1E2D45)
    val bgColor = if (isSelected) Color(0xFF0A1628) else Color(0xFF111827)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clickable { onSelect() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onSelect,
                colors = RadioButtonDefaults.colors(
                    selectedColor = Color(0xFF00D4FF),
                    unselectedColor = Color(0xFF475569)
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    provider.displayName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isSelected) Color.White else Color(0xFF94A3B8)
                )
                Text(
                    provider.defaultModel,
                    fontSize = 11.sp,
                    color = Color(0xFF475569)
                )
            }
            if (provider.isFree) {
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Color(0xFF064E3B)
                ) {
                    Text(
                        "FREE",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        color = Color(0xFF34D399),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
            }
            // Key status dot
            Surface(
                modifier = Modifier.size(8.dp),
                shape = RoundedCornerShape(4.dp),
                color = if (hasKey) Color(0xFF34D399) else Color(0xFF475569)
            ) {}
        }
    }
}

@Composable
private fun ApiKeyInput(
    provider: AiProvider,
    value: String,
    onValueChange: (String) -> Unit,
    onSave: (String) -> Unit
) {
    var visible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Text(
            provider.displayName,
            fontSize = 12.sp,
            color = Color(0xFF64748B),
            modifier = Modifier.padding(bottom = 4.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = {
                Text("API key দাও...", color = Color(0xFF334155), fontSize = 13.sp)
            },
            visualTransformation = if (visible) VisualTransformation.None
                                   else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                Row {
                    IconButton(onClick = { visible = !visible }) {
                        Icon(
                            if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = null,
                            tint = Color(0xFF475569)
                        )
                    }
                    if (value.isNotBlank()) {
                        IconButton(onClick = { onSave(value) }) {
                            Icon(
                                Icons.Default.Save,
                                contentDescription = "Save",
                                tint = Color(0xFF00D4FF)
                            )
                        }
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = Color(0xFF00D4FF),
                unfocusedBorderColor = Color(0xFF1E2D45),
                focusedTextColor     = Color.White,
                unfocusedTextColor   = Color(0xFF94A3B8),
                cursorColor          = Color(0xFF00D4FF)
            ),
            shape = RoundedCornerShape(10.dp),
            singleLine = true
        )
    }
}
