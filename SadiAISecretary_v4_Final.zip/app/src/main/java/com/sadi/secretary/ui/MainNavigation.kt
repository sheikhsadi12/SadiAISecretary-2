package com.sadi.secretary.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.sadi.secretary.faithtime.FaithTimeScreen
import com.sadi.secretary.memory.MemoryScreen
import com.sadi.secretary.persona.PersonaScreen
import com.sadi.secretary.privacy.PrivacyScreen
import com.sadi.secretary.style.StyleScreen
import com.sadi.secretary.ui.control.PendingQueueScreen
import com.sadi.secretary.ui.dashboard.DashboardScreen
import com.sadi.secretary.ui.settings.ApiSettingsScreen

sealed class AppScreen(val route: String, val label: String, val icon: ImageVector) {
    object Home     : AppScreen("home",    "Home",    Icons.Default.Home)
    object Queue    : AppScreen("queue",   "Queue",   Icons.Default.Inbox)
    object Persona  : AppScreen("persona", "Persona", Icons.Default.People)
    object Memory   : AppScreen("memory",  "Memory",  Icons.Default.Psychology)
    object Settings : AppScreen("settings","More",    Icons.Default.MoreHoriz)
}

object SettingsRoutes {
    const val API     = "settings/api"
    const val STYLE   = "settings/style"
    const val FAITH   = "settings/faith"
    const val PRIVACY = "settings/privacy"
}

@Composable
fun FullNavigation() {
    val navController = rememberNavController()
    val bottomScreens = listOf(
        AppScreen.Home, AppScreen.Queue, AppScreen.Persona,
        AppScreen.Memory, AppScreen.Settings
    )

    Scaffold(
        containerColor = Color(0xFF080C14),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D1422), tonalElevation = 0.dp) {
                val entry by navController.currentBackStackEntryAsState()
                val current = entry?.destination
                bottomScreens.forEach { screen ->
                    val selected = current?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick  = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true; restoreState = true
                            }
                        },
                        icon  = { Icon(screen.icon, screen.label) },
                        label = { Text(screen.label, fontSize = 11.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor   = Color(0xFF00D4FF),
                            selectedTextColor   = Color(0xFF00D4FF),
                            unselectedIconColor = Color(0xFF475569),
                            unselectedTextColor = Color(0xFF475569),
                            indicatorColor      = Color(0xFF00D4FF).copy(alpha = 0.1f)
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(navController, AppScreen.Home.route, Modifier.padding(padding)) {
            composable(AppScreen.Home.route)    { DashboardScreen(
                onNavigateToPending  = { navController.navigate(AppScreen.Queue.route) },
                onNavigateToContacts = { navController.navigate(AppScreen.Persona.route) }
            )}
            composable(AppScreen.Queue.route)   { PendingQueueScreen() }
            composable(AppScreen.Persona.route) { PersonaScreen() }
            composable(AppScreen.Memory.route)  { MemoryScreen() }
            composable(AppScreen.Settings.route){ SettingsHubScreen { navController.navigate(it) } }
            composable(SettingsRoutes.API)      { ApiSettingsScreen() }
            composable(SettingsRoutes.STYLE)    { StyleScreen() }
            composable(SettingsRoutes.FAITH)    { FaithTimeScreen() }
            composable(SettingsRoutes.PRIVACY)  { PrivacyScreen() }
        }
    }
}

@Composable
fun SettingsHubScreen(onNavigate: (String) -> Unit) {
    val items = listOf(
        Triple("🔑", "API Keys & Provider",  SettingsRoutes.API),
        Triple("✍️", "Style Imitation",       SettingsRoutes.STYLE),
        Triple("🕌", "Faith + Time Mode",     SettingsRoutes.FAITH),
        Triple("🔐", "Privacy Guard",         SettingsRoutes.PRIVACY),
    )
    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Settings", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("সব configuration এখানে", fontSize = 12.sp, color = Color(0xFF64748B))
            }
        }
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items.forEach { (emoji, label, route) ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onNavigate(route) },
                    shape  = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2D45))
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(emoji, fontSize = 22.sp)
                        Spacer(Modifier.width(14.dp))
                        Text(label, fontSize = 15.sp, color = Color.White, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF334155))
                    }
                }
            }
        }
    }
}
