package com.sadi.secretary.memory

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sadi.secretary.data.db.ContactEntity
import com.sadi.secretary.data.db.MemoryEntity

@Composable
fun MemoryScreen(viewModel: MemoryViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        Column(modifier = Modifier.fillMaxSize()) {
            Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Memory 🧠", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("সবার সাথে কী কথা হয়েছে মনে আছে", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
            if (uiState.contactMemories.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🧠", fontSize = 48.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("এখনো কোনো memory নেই", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Message আসলে memory তৈরি হবে", fontSize = 12.sp, color = Color(0xFF475569), modifier = Modifier.padding(top = 6.dp))
                    }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(uiState.contactMemories) { (contact, memory) ->
                        MemoryCard(contact, memory) { viewModel.selectContact(contact.id) }
                    }
                }
            }
        }
    }
}

@Composable
private fun MemoryCard(contact: ContactEntity, memory: MemoryEntity, onClick: () -> Unit) {
    val emotionEmoji = when (memory.lastEmotion) { "HAPPY" -> "😄"; "SAD" -> "😔"; "ANGRY" -> "😡"; "URGENT" -> "😰"; else -> "😐" }
    val emotionColor = when (memory.lastEmotion) { "HAPPY" -> Color(0xFF34D399); "SAD" -> Color(0xFF60A5FA); "ANGRY" -> Color(0xFFEF4444); "URGENT" -> Color(0xFFFCD34D); else -> Color(0xFF64748B) }
    val appColor = if (contact.app == "telegram") Color(0xFF26A5E4) else Color(0xFF0084FF)

    Card(modifier = Modifier.fillMaxWidth().clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF1E2D45)), contentAlignment = Alignment.Center) {
                    Text(contact.name.take(1).uppercase(), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00D4FF))
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(contact.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("${contact.app} · ${memory.messageCount} messages", fontSize = 11.sp, color = appColor)
                }
                Surface(shape = RoundedCornerShape(20.dp), color = emotionColor.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, emotionColor.copy(alpha = 0.3f))) {
                    Text("$emotionEmoji ${memory.lastEmotion.lowercase().replaceFirstChar { it.uppercase() }}",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), fontSize = 11.sp, color = emotionColor)
                }
            }
            memory.lastTopic?.let { topic ->
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.background(Color(0xFF0D1422), RoundedCornerShape(6.dp)).padding(horizontal = 10.dp, vertical = 6.dp).fillMaxWidth()) {
                    Text("💬 Last topic: $topic", fontSize = 12.sp, color = Color(0xFF94A3B8))
                }
            }
            memory.conversationSummary?.let { summary ->
                if (summary.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text("📝 $summary", fontSize = 12.sp, color = Color(0xFF64748B), maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
                }
            }
        }
    }
}
