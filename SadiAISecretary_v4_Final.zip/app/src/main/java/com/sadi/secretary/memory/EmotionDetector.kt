package com.sadi.secretary.memory

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — EmotionDetector.kt                ║
// ║        Phase 05 · Emotion Detection System                   ║
// ║                                                              ║
// ║  Message এর emotion detect করে:                              ║
// ║    HAPPY / SAD / ANGRY / NEUTRAL / URGENT                    ║
// ║                                                              ║
// ║  Features:                                                   ║
// ║    → Keyword-based fast detection (offline)                  ║
// ║    → AI-based deep detection (online)                        ║
// ║    → Emotion history track করা                               ║
// ╚══════════════════════════════════════════════════════════════╝

import javax.inject.Inject
import javax.inject.Singleton

enum class Emotion(
    val displayName: String,
    val emoji: String,
    val color: Long          // for UI
) {
    HAPPY   ("Happy",   "😄", 0xFF34D399),
    SAD     ("Sad",     "😔", 0xFF60A5FA),
    ANGRY   ("Angry",   "😡", 0xFFEF4444),
    NEUTRAL ("Neutral", "😐", 0xFF94A3B8),
    URGENT  ("Urgent",  "😰", 0xFFFCD34D)
}

@Singleton
class EmotionDetector @Inject constructor() {

    // ══════════════════════════════════════════════════════════
    // FAST DETECTION — keyword based, offline, instant
    // AI call এর আগে এটা দিয়ে quick check করা হয়
    // ══════════════════════════════════════════════════════════
    fun detectFast(text: String): Emotion {
        val lower = text.lowercase()

        // URGENT check — সবার আগে
        if (URGENT_KEYWORDS.any { lower.contains(it) }) return Emotion.URGENT

        // Count করো কোনটা বেশি match করে
        val scores = mapOf(
            Emotion.HAPPY  to HAPPY_KEYWORDS.count  { lower.contains(it) },
            Emotion.SAD    to SAD_KEYWORDS.count    { lower.contains(it) },
            Emotion.ANGRY  to ANGRY_KEYWORDS.count  { lower.contains(it) }
        )

        val maxScore = scores.values.maxOrNull() ?: 0
        if (maxScore == 0) return Emotion.NEUTRAL

        return scores.entries.maxByOrNull { it.value }?.key ?: Emotion.NEUTRAL
    }

    // String থেকে Emotion object বানানো
    fun fromString(emotionStr: String): Emotion {
        return try {
            Emotion.valueOf(emotionStr.uppercase())
        } catch (e: Exception) {
            Emotion.NEUTRAL
        }
    }

    // AI response থেকে emotion parse করা
    fun parseAiResponse(response: String): Emotion {
        val cleaned = response.trim().uppercase()
        return Emotion.values().find { it.name == cleaned } ?: Emotion.NEUTRAL
    }

    // ══════════════════════════════════════════════════════════
    // KEYWORD DICTIONARIES — Bangla + English + Banglish
    // ══════════════════════════════════════════════════════════

    private val HAPPY_KEYWORDS = setOf(
        // Bangla
        "ভালো", "খুশি", "আনন্দ", "হাসি", "মজা", "দারুণ", "অসাধারণ",
        "সুন্দর", "ভালোবাসি", "ধন্যবাদ", "শুকরিয়া", "আলহামদুলিল্লাহ",
        // Banglish
        "valo", "khushi", "darun", "onek valo", "bhalo", "happy",
        "alhamdulillah", "mazha", "fun", "nice", "great", "awesome",
        // Emoji patterns
        "😄", "😊", "🥰", "❤️", "💕", "😁", "🎉", "✨", "🔥", "😍",
        "haha", "hehe", "lol", "😂", "🤣"
    )

    private val SAD_KEYWORDS = setOf(
        // Bangla
        "মন খারাপ", "কষ্ট", "কাঁদছি", "দুঃখ", "একা", "মিস করছি",
        "ক্লান্ত", "চিন্তা", "ভয়", "হতাশ", "কাঁদতে", "কান্না",
        // Banglish
        "mon kharap", "kosto", "kandchi", "miss korchi", "klanto",
        "chinta", "sad", "hurt", "depressed", "upset", "tired",
        "lonely", "miss u", "miss you",
        // Emoji
        "😔", "😢", "😭", "💔", "😞", "🥺", "😓"
    )

    private val ANGRY_KEYWORDS = setOf(
        // Bangla
        "রাগ", "বিরক্ত", "বিরক্তিকর", "রেগে", "ঘৃণা", "বাজে",
        "মিথ্যা", "ধোকা", "বিশ্বাসঘাতক",
        // Banglish
        "rag", "birakt", "hate", "angry", "frustrat", "annoyed",
        "stop", "enough", "fed up", "bakwas", "bekar",
        // Emoji
        "😡", "🤬", "😤", "💢", "🖕"
    )

    private val URGENT_KEYWORDS = setOf(
        // Bangla
        "জরুরি", "এখনই", "তাড়াতাড়ি", "হেল্প", "বিপদ", "সাহায্য",
        "পড়েছি", "দ্রুত", "আসো", "জলদি",
        // Banglish
        "urgent", "help", "asap", "jaldi", "taratari", "bipod",
        "emergency", "please", "ekhoni", "call me", "call koro",
        // Symbols
        "!!!", "???"
    )
}
