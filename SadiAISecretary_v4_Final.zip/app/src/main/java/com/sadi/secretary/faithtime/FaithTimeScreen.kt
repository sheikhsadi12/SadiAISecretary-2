package com.sadi.secretary.faithtime

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — FaithTimeScreen.kt                 ║
// ║       Phase 07 · Faith + Time Settings UI                    ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun FaithTimeScreen(
    viewModel: FaithTimeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    uiState.toastMessage?.let { msg ->
        LaunchedEffect(msg) {
            kotlinx.coroutines.delay(2000)
            viewModel.clearToast()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF080C14))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {

            // ── Header ─────────────────────────────────────────
            Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Faith + Time Mode 🕌", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("সময় ও দ্বীন অনুযায়ী AI এর tone পরিবর্তন হবে", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ── Current Time Context ───────────────────────────
            CurrentTimeCard(timeContext = uiState.currentTimeContext)

            Spacer(modifier = Modifier.height(16.dp))

            // ── Mode Toggles ───────────────────────────────────
            SectionLabel("MODES")
            ModesCard(
                modes    = uiState.activeModes,
                onChange = { viewModel.updateModes(it) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ── Quick Replies ──────────────────────────────────
            SectionLabel("QUICK REPLY SUGGESTIONS")
            QuickRepliesCard(suggestions = uiState.quickReplySuggestions)

            Spacer(modifier = Modifier.height(16.dp))

            // ── Schedule ───────────────────────────────────────
            SectionLabel("AI SCHEDULE")
            ScheduleCard(
                config   = uiState.scheduleConfig,
                isActive = uiState.isAiActiveNow,
                onChange = { viewModel.updateSchedule(it) }
            )

            Spacer(modifier = Modifier.height(40.dp))
        }

        // Toast
        uiState.toastMessage?.let { msg ->
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF1E2D45)
            ) {
                Text(msg, modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp), color = Color(0xFF00D4FF), fontSize = 13.sp)
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// CURRENT TIME CARD
// ══════════════════════════════════════════════════════════════
@Composable
private fun CurrentTimeCard(timeContext: TimeContext) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(timeContext.emoji, fontSize = 32.sp)
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text("এখন", fontSize = 11.sp, color = Color(0xFF64748B), letterSpacing = 1.sp)
                Text(timeContext.displayName, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("AI এই tone এ reply দিচ্ছে", fontSize = 11.sp, color = Color(0xFF475569), modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// MODES CARD
// ══════════════════════════════════════════════════════════════
@Composable
private fun ModesCard(modes: ActiveModes, onChange: (ActiveModes) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {

            ModeRow("🕌", "Faith Mode",
                "ইনশাআল্লাহ, আলহামদুলিল্লাহ, Islamic tone",
                modes.faithModeEnabled, Color(0xFF5EEAD4)
            ) { onChange(modes.copy(faithModeEnabled = it)) }

            Divider(color = Color(0xFF1E2D45), modifier = Modifier.padding(vertical = 6.dp))

            ModeRow("🌙", "Islamic Greeting",
                "নতুন conversation এ সালাম দিয়ে শুরু",
                modes.islamicGreeting, Color(0xFF5EEAD4)
            ) { onChange(modes.copy(islamicGreeting = it)) }

            Divider(color = Color(0xFF1E2D45), modifier = Modifier.padding(vertical = 6.dp))

            ModeRow("⏳", "Busy Mode",
                "সব reply ১ line এ — ব্যস্ত থাকলে চালু করো",
                modes.busyModeEnabled, Color(0xFFFCD34D)
            ) { onChange(modes.copy(busyModeEnabled = it)) }

            Divider(color = Color(0xFF1E2D45), modifier = Modifier.padding(vertical = 6.dp))

            ModeRow("🔇", "Silent Mode",
                "কোনো AI reply যাবে না — পুরোপুরি বন্ধ",
                modes.silentModeEnabled, Color(0xFFFCA5A5)
            ) { onChange(modes.copy(silentModeEnabled = it)) }
        }
    }
}

@Composable
private fun ModeRow(
    icon: String,
    title: String,
    description: String,
    checked: Boolean,
    activeColor: Color,
    onToggle: (Boolean) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 20.sp)
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Color.White)
            Text(description, fontSize = 11.sp, color = Color(0xFF64748B), lineHeight = 16.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedTrackColor   = activeColor.copy(alpha = 0.7f),
                uncheckedTrackColor = Color(0xFF1E2D45),
                checkedThumbColor   = Color.White,
                uncheckedThumbColor = Color(0xFF475569)
            )
        )
    }
}

// ══════════════════════════════════════════════════════════════
// QUICK REPLIES CARD
// ══════════════════════════════════════════════════════════════
@Composable
private fun QuickRepliesCard(suggestions: List<String>) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1628)),
        border = BorderStroke(1.dp, Color(0xFF1E3A5F))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                "এই সময়ের জন্য suggested replies:",
                fontSize = 12.sp, color = Color(0xFF7DD3FC), fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(10.dp))
            suggestions.forEach { reply ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .background(Color(0xFF111827), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text("💬 ", fontSize = 13.sp)
                    Text(reply, fontSize = 13.sp, color = Color(0xFF94A3B8))
                }
            }
        }
    }
}

// ══════════════════════════════════════════════════════════════
// SCHEDULE CARD
// ══════════════════════════════════════════════════════════════
@Composable
private fun ScheduleCard(
    config: ScheduleConfig,
    isActive: Boolean,
    onChange: (ScheduleConfig) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Enable toggle
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Custom Schedule", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("AI কখন active থাকবে তুমি set করো", fontSize = 12.sp, color = Color(0xFF64748B))
                }
                Switch(
                    checked = config.isScheduleEnabled,
                    onCheckedChange = { onChange(config.copy(isScheduleEnabled = it)) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Color(0xFF00D4FF).copy(alpha = 0.7f),
                        uncheckedTrackColor = Color(0xFF1E2D45)
                    )
                )
            }

            if (config.isScheduleEnabled) {
                Spacer(modifier = Modifier.height(14.dp))
                Divider(color = Color(0xFF1E2D45))
                Spacer(modifier = Modifier.height(14.dp))

                // Current status
                val statusColor = if (isActive) Color(0xFF34D399) else Color(0xFFFCA5A5)
                val statusText  = if (isActive) "AI এখন ACTIVE 🟢" else "AI এখন OFF 🔴"
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusColor.copy(alpha = 0.1f),
                    border = BorderStroke(1.dp, statusColor.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        statusText,
                        modifier = Modifier.padding(10.dp),
                        color = statusColor,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Time display
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    TimeBlock(
                        label = "AI চালু হবে",
                        hour  = config.activeStartHour,
                        min   = config.activeStartMinute,
                        color = Color(0xFF34D399)
                    )
                    Text("→", fontSize = 20.sp, color = Color(0xFF475569), modifier = Modifier.align(Alignment.CenterVertically))
                    TimeBlock(
                        label = "AI বন্ধ হবে",
                        hour  = config.activeEndHour,
                        min   = config.activeEndMinute,
                        color = Color(0xFFFCA5A5)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    "⚙️ Time picker Phase 10 Dashboard এ পুরোপুরি implement হবে",
                    fontSize = 11.sp,
                    color = Color(0xFF334155),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun TimeBlock(label: String, hour: Int, min: Int, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 10.sp, color = Color(0xFF64748B))
        Spacer(modifier = Modifier.height(4.dp))
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = color.copy(alpha = 0.1f),
            border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
        ) {
            Text(
                "%02d:%02d".format(hour, min),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        fontSize = 10.sp,
        color = Color(0xFF64748B),
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}
