package com.sadi.secretary.style

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — StyleViewModel.kt                 ║
// ║        Phase 06 · Style ViewModel                            ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StyleUiState(
    val styleConfig: StyleConfig = StyleConfig(),
    val isAnalyzing: Boolean = false,
    val toastMessage: String? = null
)

@HiltViewModel
class StyleViewModel @Inject constructor(
    private val styleManager: StyleManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(StyleUiState())
    val uiState: StateFlow<StyleUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            styleManager.styleFlow.collect { config ->
                _uiState.update { it.copy(styleConfig = config) }
            }
        }
    }

    fun reAnalyze() {
        viewModelScope.launch {
            _uiState.update { it.copy(isAnalyzing = true) }
            val config = styleManager.analyzeAndSave()
            _uiState.update { it.copy(styleConfig = config, isAnalyzing = false, toastMessage = "Style re-analyzed! ✅") }
        }
    }

    fun setEmojiFreq(freq: EmojiFreq) {
        applyOverride(StyleOverride.EmojiFrequency(freq), "Emoji frequency updated")
    }

    fun setSentenceStyle(style: SentenceStyle) {
        applyOverride(StyleOverride.SentenceLength(style), "Sentence style updated")
    }

    fun setPuncStyle(style: PuncStyle) {
        applyOverride(StyleOverride.PunctuationStyle(style), "Punctuation style updated")
    }

    fun addSlang(word: String) {
        applyOverride(StyleOverride.AddSlang(word), "\"$word\" added ✅")
    }

    fun removeSlang(word: String) {
        applyOverride(StyleOverride.RemoveSlang(word), "\"$word\" removed")
    }

    private fun applyOverride(override: StyleOverride, toast: String) {
        viewModelScope.launch {
            styleManager.applyManualOverride(override)
            _uiState.update { it.copy(toastMessage = toast) }
        }
    }

    fun clearToast() = _uiState.update { it.copy(toastMessage = null) }
}
