package com.sadi.secretary.privacy

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — PrivacyScreen.kt                   ║
// ║       Phase 09 · Privacy Settings UI                         ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PrivacyScreen() {
    val scrollState = rememberScrollState()

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(scrollState)) {

            // Header
            Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Privacy Guard 🔐", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("তোমার data সম্পূর্ণ safe এবং encrypted", fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Security status
            SecurityStatusCard()
            Spacer(modifier = Modifier.height(12.dp))

            // Privacy rules list
            SectionLabel("BUILT-IN PRIVACY RULES")
            PrivacyRulesList()
            Spacer(modifier = Modifier.height(12.dp))

            // Data info
            SectionLabel("DATA STORAGE")
            DataInfoCard()

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun SecurityStatusCard() {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A2018)),
        border = BorderStroke(1.dp, Color(0xFF064E3B))
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🔒", fontSize = 32.sp)
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text("সব data protected", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
                Text("AES-256 encryption active", fontSize = 12.sp, color = Color(0xFF065F46), modifier = Modifier.padding(top = 2.dp))
                Text("কোনো data server এ যায় না (API call ছাড়া)", fontSize = 11.sp, color = Color(0xFF047857), modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

@Composable
private fun PrivacyRulesList() {
    val rules = listOf(
        Triple("💝", "LOVE contact", "Auto-send সবসময় OFF — manually approve করতে হবে"),
        Triple("👥", "Group chat", "AI reply suggest only — কখনো auto-send না"),
        Triple("👤", "Unknown contact", "নতুন/unknown contact এ AI reply করে না"),
        Triple("🔑", "Sensitive keywords", "Bank, OTP, password থাকলে force manual mode"),
        Triple("🚫", "Inappropriate content", "Blocked keywords detect হলে reply বন্ধ"),
        Triple("📱", "Phone numbers", "API call এর আগে phone number mask হয়ে যায়"),
    )

    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            rules.forEach { (emoji, title, desc) ->
                Row(verticalAlignment = Alignment.Top) {
                    Text(emoji, fontSize = 18.sp, modifier = Modifier.padding(top = 2.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(desc, fontSize = 12.sp, color = Color(0xFF64748B), lineHeight = 16.sp)
                    }
                }
                if (rules.last() != Triple(emoji, title, desc)) {
                    Divider(color = Color(0xFF1E2D45))
                }
            }
        }
    }
}

@Composable
private fun DataInfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0A1628)),
        border = BorderStroke(1.dp, Color(0xFF1E3A5F))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Data কোথায় যায়?", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF7DD3FC))
            DataRow("📱", "Messages + Memory", "Phone এর local storage এ (encrypted)")
            DataRow("🔑", "API Keys", "Android Keystore এ secure storage")
            DataRow("🌐", "AI API call", "শুধু message text যায় — sanitized")
            DataRow("🚫", "Cloud/Server", "কিছুই যায় না — সব local")
        }
    }
}

@Composable
private fun DataRow(emoji: String, label: String, value: String) {
    Row(verticalAlignment = Alignment.Top) {
        Text(emoji, fontSize = 14.sp)
        Spacer(modifier = Modifier.width(8.dp))
        Text("$label: ", fontSize = 12.sp, color = Color(0xFF94A3B8), fontWeight = FontWeight.Medium)
        Text(value, fontSize = 12.sp, color = Color(0xFF475569))
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text, fontSize = 10.sp, color = Color(0xFF64748B),
        fontWeight = FontWeight.Bold, letterSpacing = 2.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}
