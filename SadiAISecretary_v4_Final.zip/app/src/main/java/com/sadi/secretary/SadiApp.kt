package com.sadi.secretary

// ╔══════════════════════════════════════════════════════════════╗
// ║              SADI AI SECRETARY — SadiApp.kt                  ║
// ║              Phase 00 · Application Entry Point              ║
// ╚══════════════════════════════════════════════════════════════╝

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SadiApp : Application() {

    companion object {
        // Notification Channel IDs
        const val CHANNEL_FOREGROUND   = "sadi_foreground"    // Always-on service
        const val CHANNEL_REPLY        = "sadi_reply"         // AI reply preview
        const val CHANNEL_ALERT        = "sadi_alert"         // Important alerts

        // App-wide constants
        const val DB_NAME              = "sadi_database"
        const val PREFS_NAME           = "sadi_prefs"

        // Supported messaging apps (Phase 1 — Messenger + Telegram)
        val SUPPORTED_APPS = setOf(
            "com.facebook.orca",          // Messenger
            "org.telegram.messenger",     // Telegram
            // "com.whatsapp",            // WhatsApp → Phase later
        )
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    // ──────────────────────────────────────────────────────────────
    // Notification Channels তৈরি করা
    // Android 8+ এ required
    // ──────────────────────────────────────────────────────────────
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)

            // Channel 1: Foreground Service — always visible
            // "Sadi AI চলছে 🟢" — এটাই app কে alive রাখে
            val foregroundChannel = NotificationChannel(
                CHANNEL_FOREGROUND,
                "Sadi AI Status",
                NotificationManager.IMPORTANCE_LOW       // Silent, no sound
            ).apply {
                description = "Sadi AI Secretary background service"
                setShowBadge(false)
            }

            // Channel 2: Reply Preview — যখন AI reply ready হয়
            val replyChannel = NotificationChannel(
                CHANNEL_REPLY,
                "AI Reply Ready",
                NotificationManager.IMPORTANCE_HIGH      // Heads-up notification
            ).apply {
                description = "AI has a reply ready for your approval"
                setShowBadge(true)
            }

            // Channel 3: Alerts — errors, important notices
            val alertChannel = NotificationChannel(
                CHANNEL_ALERT,
                "Sadi Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "System alerts and notifications"
            }

            manager.createNotificationChannels(
                listOf(foregroundChannel, replyChannel, alertChannel)
            )
        }
    }
}
