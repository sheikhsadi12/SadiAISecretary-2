package com.sadi.secretary.faithtime

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — ScheduleManager.kt                 ║
// ║       Phase 07 · Custom Schedule System                      ║
// ║                                                              ║
// ║  তুমি set করবে AI কখন active থাকবে:                         ║
// ║    Example: রাত ৯টা → সকাল ৬টা = AI ON                      ║
// ║             সকাল ৬টা → রাত ৯টা = AI OFF (manual only)       ║
// ╚══════════════════════════════════════════════════════════════╝

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sadi.secretary.receivers.ScheduleReceiver
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

private val Context.scheduleDataStore by preferencesDataStore(name = "sadi_schedule")

data class ScheduleConfig(
    val isScheduleEnabled: Boolean = false,
    val activeStartHour: Int = 21,    // রাত ৯টা
    val activeStartMinute: Int = 0,
    val activeEndHour: Int = 6,       // সকাল ৬টা
    val activeEndMinute: Int = 0,
    val activeDays: Set<Int> = setOf(1,2,3,4,5,6,7) // সব দিন (1=Sun...7=Sat)
)

@Singleton
class ScheduleManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val TAG = "SadiSchedule"
        private val KEY_ENABLED      = booleanPreferencesKey("schedule_enabled")
        private val KEY_START_HOUR   = intPreferencesKey("start_hour")
        private val KEY_START_MIN    = intPreferencesKey("start_min")
        private val KEY_END_HOUR     = intPreferencesKey("end_hour")
        private val KEY_END_MIN      = intPreferencesKey("end_min")
    }

    // ══════════════════════════════════════════════════════════
    // SCHEDULE CONFIG — load/save
    // ══════════════════════════════════════════════════════════
    val scheduleFlow: Flow<ScheduleConfig> = context.scheduleDataStore.data.map { prefs ->
        ScheduleConfig(
            isScheduleEnabled = prefs[KEY_ENABLED] ?: false,
            activeStartHour   = prefs[KEY_START_HOUR] ?: 21,
            activeStartMinute = prefs[KEY_START_MIN] ?: 0,
            activeEndHour     = prefs[KEY_END_HOUR] ?: 6,
            activeEndMinute   = prefs[KEY_END_MIN] ?: 0
        )
    }

    suspend fun saveSchedule(config: ScheduleConfig) {
        context.scheduleDataStore.edit { prefs ->
            prefs[KEY_ENABLED]    = config.isScheduleEnabled
            prefs[KEY_START_HOUR] = config.activeStartHour
            prefs[KEY_START_MIN]  = config.activeStartMinute
            prefs[KEY_END_HOUR]   = config.activeEndHour
            prefs[KEY_END_MIN]    = config.activeEndMinute
        }
        // Alarms reschedule করো
        if (config.isScheduleEnabled) {
            scheduleAlarms(config)
        } else {
            cancelAlarms()
        }
        Log.d(TAG, "Schedule saved: ${config.activeStartHour}:${config.activeStartMinute} → ${config.activeEndHour}:${config.activeEndMinute}")
    }

    // ══════════════════════════════════════════════════════════
    // IS AI CURRENTLY ACTIVE?
    // ══════════════════════════════════════════════════════════
    suspend fun isAiActiveNow(): Boolean {
        val config = scheduleFlow.first()

        // Schedule disabled হলে সবসময় active
        if (!config.isScheduleEnabled) return true

        val cal     = Calendar.getInstance()
        val nowMins = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val startMins = config.activeStartHour * 60 + config.activeStartMinute
        val endMins   = config.activeEndHour * 60 + config.activeEndMinute

        // Overnight schedule (e.g. 21:00 → 06:00)
        return if (startMins > endMins) {
            nowMins >= startMins || nowMins < endMins
        } else {
            nowMins in startMins until endMins
        }
    }

    // ══════════════════════════════════════════════════════════
    // ALARMS — AlarmManager দিয়ে auto on/off
    // ══════════════════════════════════════════════════════════
    private fun scheduleAlarms(config: ScheduleConfig) {
        val alarmManager = context.getSystemService(AlarmManager::class.java)

        // Start alarm
        val startIntent = PendingIntent.getBroadcast(
            context, 100,
            Intent(context, ScheduleReceiver::class.java).apply {
                action = "com.sadi.secretary.ACTION_AI_START"
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Stop alarm
        val stopIntent = PendingIntent.getBroadcast(
            context, 101,
            Intent(context, ScheduleReceiver::class.java).apply {
                action = "com.sadi.secretary.ACTION_AI_STOP"
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val startCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, config.activeStartHour)
            set(Calendar.MINUTE, config.activeStartMinute)
            set(Calendar.SECOND, 0)
            if (timeInMillis < System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val stopCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, config.activeEndHour)
            set(Calendar.MINUTE, config.activeEndMinute)
            set(Calendar.SECOND, 0)
            if (timeInMillis < System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        // Daily repeating alarms
        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            startCal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            startIntent
        )
        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            stopCal.timeInMillis,
            AlarmManager.INTERVAL_DAY,
            stopIntent
        )

        Log.d(TAG, "Alarms scheduled: ON at ${config.activeStartHour}:${config.activeStartMinute}, OFF at ${config.activeEndHour}:${config.activeEndMinute}")
    }

    private fun cancelAlarms() {
        val alarmManager = context.getSystemService(AlarmManager::class.java)
        listOf(100, 101).forEach { requestCode ->
            val intent = PendingIntent.getBroadcast(
                context, requestCode,
                Intent(context, ScheduleReceiver::class.java),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            intent?.let { alarmManager.cancel(it) }
        }
        Log.d(TAG, "Alarms cancelled")
    }
}
