package com.sadi.secretary.style

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — StyleAnalyzer.kt                  ║
// ║        Phase 06 · Writing Style Analyzer                     ║
// ║                                                              ║
// ║  তোমার পুরনো messages analyze করে style বের করে:            ║
// ║    → Average sentence length                                 ║
// ║    → Emoji frequency                                         ║
// ║    → Common slang/words                                      ║
// ║    → Punctuation habits                                      ║
// ║    → Bangla vs English ratio                                 ║
// ╚══════════════════════════════════════════════════════════════╝

import android.util.Log
import javax.inject.Inject
import javax.inject.Singleton

// Style config — analyze করার পর এটা save হবে
data class StyleConfig(
    val avgWordCount: Float = 8f,           // average words per message
    val emojiFrequency: EmojiFreq = EmojiFreq.MEDIUM,
    val usesSlang: List<String> = SADI_DEFAULT_SLANG,
    val punctuationStyle: PuncStyle = PuncStyle.MINIMAL,
    val banglaRatio: Float = 0.6f,          // 0.0 (all english) → 1.0 (all bangla)
    val commonPhrases: List<String> = SADI_DEFAULT_PHRASES,
    val sentenceStyle: SentenceStyle = SentenceStyle.SHORT,
    val usesEllipsis: Boolean = true,       // "hm..." "accha..."
    val lastAnalyzed: Long = 0L
)

enum class EmojiFreq(val displayName: String, val maxPerMsg: Int) {
    NONE   ("Emoji নেই",   0),
    LOW    ("কম emoji",    1),
    MEDIUM ("মাঝে মাঝে",  2),
    HIGH   ("বেশি emoji",  4)
}

enum class PuncStyle(val displayName: String) {
    MINIMAL  ("Minimal — sentence এ শুধু দরকারে"),
    MODERATE ("Moderate — normal punctuation"),
    HEAVY    ("Heavy — lots of !!! ???")
}

enum class SentenceStyle(val displayName: String) {
    SHORT  ("Short — ১-৫ words"),
    MEDIUM ("Medium — ৫-১৫ words"),
    LONG   ("Long — ১৫+ words")
}

// Sadi এর default style (যতক্ষণ analyze না হয়)
private val SADI_DEFAULT_SLANG = listOf(
    "vai", "bro", "accha", "hm", "uff", "sotti",
    "ektu", "onek", "janina", "dekhi", "thik ache",
    "ইনশাআল্লাহ", "আলহামদুলিল্লাহ", "maaf koro", "haha"
)

private val SADI_DEFAULT_PHRASES = listOf(
    "ইনশাআল্লাহ", "accha", "hm", "thik ache", "ok",
    "sotti boltesi", "janina vai", "dekhi ki hoy"
)

@Singleton
class StyleAnalyzer @Inject constructor() {

    companion object {
        private const val TAG = "SadiStyleAnalyzer"
    }

    // ══════════════════════════════════════════════════════════
    // ANALYZE — past messages থেকে style বের করো
    // ══════════════════════════════════════════════════════════
    fun analyze(sentMessages: List<String>): StyleConfig {
        if (sentMessages.size < 5) {
            Log.d(TAG, "Not enough messages to analyze, using defaults")
            return StyleConfig()
        }

        Log.d(TAG, "Analyzing ${sentMessages.size} messages for style...")

        val avgWords = sentMessages
            .map { it.split(" ").filter { w -> w.isNotBlank() }.size }
            .average().toFloat()

        val emojiCount = sentMessages.sumOf { countEmojis(it) }
        val emojiFreq = when {
            emojiCount == 0                           -> EmojiFreq.NONE
            emojiCount < sentMessages.size * 0.3      -> EmojiFreq.LOW
            emojiCount < sentMessages.size * 0.7      -> EmojiFreq.MEDIUM
            else                                      -> EmojiFreq.HIGH
        }

        val banglaChars = sentMessages.sumOf { msg ->
            msg.count { c -> c.code in 0x0980..0x09FF }
        }
        val totalChars = sentMessages.sumOf { it.length }.coerceAtLeast(1)
        val banglaRatio = banglaChars.toFloat() / totalChars

        val heavyPunc = sentMessages.count { it.contains("!!!") || it.contains("???") }
        val punctStyle = when {
            heavyPunc > sentMessages.size * 0.3 -> PuncStyle.HEAVY
            heavyPunc > sentMessages.size * 0.1 -> PuncStyle.MODERATE
            else                                 -> PuncStyle.MINIMAL
        }

        val sentenceStyle = when {
            avgWords < 5  -> SentenceStyle.SHORT
            avgWords < 15 -> SentenceStyle.MEDIUM
            else          -> SentenceStyle.LONG
        }

        val usesEllipsis = sentMessages.count { it.contains("...") || it.contains("…") } >
                           sentMessages.size * 0.2

        // Most used words extract
        val foundSlang = SADI_DEFAULT_SLANG.filter { slang ->
            sentMessages.any { it.lowercase().contains(slang.lowercase()) }
        }

        val config = StyleConfig(
            avgWordCount    = avgWords,
            emojiFrequency  = emojiFreq,
            usesSlang       = foundSlang.ifEmpty { SADI_DEFAULT_SLANG },
            punctuationStyle = punctStyle,
            banglaRatio     = banglaRatio,
            sentenceStyle   = sentenceStyle,
            usesEllipsis    = usesEllipsis,
            lastAnalyzed    = System.currentTimeMillis()
        )

        Log.d(TAG, "Style analyzed: avgWords=$avgWords, emoji=$emojiFreq, bangla=${banglaRatio}")
        return config
    }

    // ══════════════════════════════════════════════════════════
    // BUILD STYLE PROMPT — AI prompt এ inject হবে
    // ══════════════════════════════════════════════════════════
    fun buildStylePrompt(config: StyleConfig): String = buildString {
        appendLine("## Writing Style Rules (exactly follow করো):")
        appendLine()

        // Sentence length
        appendLine(when (config.sentenceStyle) {
            SentenceStyle.SHORT  -> "• Reply সংক্ষিপ্ত রাখো — সাধারণত ১-৫ words"
            SentenceStyle.MEDIUM -> "• Reply medium length — ৫-১৫ words"
            SentenceStyle.LONG   -> "• Reply একটু বিস্তারিত হতে পারে"
        })

        // Emoji
        appendLine(when (config.emojiFrequency) {
            EmojiFreq.NONE   -> "• Emoji একদম use করবে না"
            EmojiFreq.LOW    -> "• Emoji কম ব্যবহার করো — দরকারে ১টা"
            EmojiFreq.MEDIUM -> "• মাঝে মাঝে emoji — message এ ১-২টা max"
            EmojiFreq.HIGH   -> "• Emoji freely use করো"
        })

        // Punctuation
        appendLine(when (config.punctuationStyle) {
            PuncStyle.MINIMAL  -> "• Punctuation কম — sentence এ শেষে দরকার নেই সবসময়"
            PuncStyle.MODERATE -> "• Normal punctuation use করো"
            PuncStyle.HEAVY    -> "• Expressive হতে পারো — !, ? use করো"
        })

        // Bangla/English mix
        val banglaPercent = (config.banglaRatio * 100).toInt()
        appendLine("• Language mix: ~${banglaPercent}% Bangla, ~${100 - banglaPercent}% English/Banglish")

        // Ellipsis
        if (config.usesEllipsis) {
            appendLine("• মাঝে মাঝে \"...\" use করো naturally — \"accha...\", \"hm...\"")
        }

        // Slang
        if (config.usesSlang.isNotEmpty()) {
            val slangList = config.usesSlang.take(8).joinToString(", ")
            appendLine("• Common words/slang: $slangList")
            appendLine("• এই words naturally mix করো reply এ")
        }
    }

    private fun countEmojis(text: String): Int {
        return text.codePoints()
            .filter { cp ->
                (cp in 0x1F600..0x1F64F) ||  // Emoticons
                (cp in 0x1F300..0x1F5FF) ||  // Misc symbols
                (cp in 0x1F680..0x1F6FF) ||  // Transport
                (cp in 0x2600..0x26FF)   ||  // Misc symbols
                (cp in 0x2700..0x27BF)       // Dingbats
            }.count().toInt()
    }
}
