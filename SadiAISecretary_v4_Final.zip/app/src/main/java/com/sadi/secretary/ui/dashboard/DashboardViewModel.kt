package com.sadi.secretary.ui.dashboard

// ╔══════════════════════════════════════════════════════════════╗
// ║       SADI AI SECRETARY — DashboardViewModel.kt              ║
// ║       Phase 10 · Dashboard ViewModel                         ║
// ╚══════════════════════════════════════════════════════════════╝

import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sadi.secretary.ai.AiProvider
import com.sadi.secretary.ai.AiSettingsManager
import com.sadi.secretary.data.repository.MessageRepository
import com.sadi.secretary.services.SadiForegroundService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class DashboardUiState(
    val isAiActive: Boolean = true,
    val isBusyMode: Boolean = false,
    val isFaithMode: Boolean = true,
    val isSilentMode: Boolean = false,
    val pendingCount: Int = 0,
    val todayStats: TodayStats = TodayStats(),
    val recentActivities: List<ActivityItem> = emptyList(),
    val activeProviderName: String = AiProvider.CLAUDE.displayName,
    val isProviderConfigured: Boolean = false
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repository: MessageRepository,
    private val settingsManager: AiSettingsManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        observePendingCount()
        loadStats()
        loadProviderInfo()
    }

    private fun observePendingCount() {
        viewModelScope.launch {
            repository.getPendingCount().collect { count ->
                _uiState.update { it.copy(pendingCount = count) }
            }
        }
    }

    private fun loadStats() {
        viewModelScope.launch {
            // Today's message count
            repository.getAllMessages().collect { messages ->
                val todayStart = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                }.timeInMillis

                val todayMessages = messages.filter { it.timestamp >= todayStart }
                val sent    = todayMessages.count { it.isReplied }
                val pending = todayMessages.count { !it.isReplied }

                // Recent activity বানাও
                val activities = todayMessages.take(5).map { msg ->
                    val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault())
                        .format(Date(msg.timestamp))
                    ActivityItem(
                        emoji = when (msg.senderApp) {
                            "telegram"  -> "✈️"
                            "messenger" -> "💬"
                            else        -> "📩"
                        },
                        text  = "${msg.senderName}: ${msg.messageText.take(30)}...",
                        time  = timeStr,
                        color = Color(0xFF64748B)
                    )
                }

                _uiState.update { state ->
                    state.copy(
                        todayStats = TodayStats(
                            messagesReceived = todayMessages.size,
                            repliesSent      = sent,
                            autoSent         = sent,  // Phase 8 integration এ refine হবে
                            pending          = pending
                        ),
                        recentActivities = activities
                    )
                }
            }
        }
    }

    private fun loadProviderInfo() {
        viewModelScope.launch {
            settingsManager.selectedProvider.collect { provider ->
                val hasKey = settingsManager.hasApiKey(provider)
                _uiState.update {
                    it.copy(
                        activeProviderName  = provider.displayName,
                        isProviderConfigured = hasKey
                    )
                }
            }
        }
    }

    // ── Toggle functions ───────────────────────────────────────
    fun toggleAi() {
        val newState = !_uiState.value.isAiActive
        _uiState.update { it.copy(isAiActive = newState) }
        // TODO: SadiForegroundService pause/resume
    }

    fun toggleBusy() {
        _uiState.update { it.copy(isBusyMode = !it.isBusyMode) }
    }

    fun toggleFaith() {
        _uiState.update { it.copy(isFaithMode = !it.isFaithMode) }
    }

    fun toggleSilent() {
        _uiState.update { it.copy(isSilentMode = !it.isSilentMode) }
    }
}
