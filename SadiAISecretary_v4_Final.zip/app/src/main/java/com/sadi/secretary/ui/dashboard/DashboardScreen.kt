package com.sadi.secretary.ui.dashboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel = hiltViewModel(),
    onNavigateToPending: () -> Unit = {},
    onNavigateToContacts: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF080C14))) {
        Column(modifier = Modifier.fillMaxSize().verticalScroll(scrollState)) {

            // Top Bar
            Surface(color = Color(0xFF0D1422), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Sadi AI Secretary", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Digital You System", fontSize = 11.sp, color = Color(0xFF475569))
                    }
                    Box(modifier = Modifier.size(10.dp).background(Color(0xFF34D399), CircleShape))
                }
            }

            // AI Status Card
            AiStatusCard(uiState.isAiActive, uiState.isBusyMode, uiState.isFaithMode) { viewModel.toggleAi() }

            Spacer(Modifier.height(16.dp))

            // Quick Mode Buttons
            DashSectionLabel("QUICK MODES")
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickBtn("⏳", "Busy", uiState.isBusyMode, Color(0xFFFCD34D), { viewModel.toggleBusy() }, Modifier.weight(1f))
                QuickBtn("🕌", "Faith", uiState.isFaithMode, Color(0xFF5EEAD4), { viewModel.toggleFaith() }, Modifier.weight(1f))
                QuickBtn("🔇", "Silent", uiState.isSilentMode, Color(0xFFFCA5A5), { viewModel.toggleSilent() }, Modifier.weight(1f))
            }

            Spacer(Modifier.height(16.dp))

            // Stats
            DashSectionLabel("আজকের Stats")
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard2("📩", "${uiState.todayStats.messagesReceived}", "Received", Color(0xFF00D4FF), Modifier.weight(1f))
                StatCard2("✅", "${uiState.todayStats.repliesSent}", "Sent", Color(0xFF34D399), Modifier.weight(1f))
                StatCard2("⚡", "${uiState.todayStats.autoSent}", "Auto", Color(0xFFA78BFA), Modifier.weight(1f))
                StatCard2("⏳", "${uiState.todayStats.pending}", "Pending", Color(0xFFFCD34D), Modifier.weight(1f))
            }

            // Pending Alert
            if (uiState.pendingCount > 0) {
                Spacer(Modifier.height(16.dp))
                Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { onNavigateToPending() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A0A)),
                    border = BorderStroke(1.dp, Color(0xFFFCD34D).copy(alpha = 0.5f))) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⏳", fontSize = 24.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${uiState.pendingCount} টা reply অপেক্ষায়", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFFFCD34D))
                            Text("দেখতে tap করো", fontSize = 12.sp, color = Color(0xFF64748B))
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFFFCD34D))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Provider
            DashSectionLabel("AI PROVIDER")
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                border = BorderStroke(1.dp, Color(0xFF1E2D45))) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🧠", fontSize = 20.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Active: ${uiState.activeProviderName}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(if (uiState.isProviderConfigured) "API key configured ✅" else "API key missing ⚠️",
                            fontSize = 12.sp, color = if (uiState.isProviderConfigured) Color(0xFF34D399) else Color(0xFFFCD34D))
                    }
                }
            }

            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun AiStatusCard(isActive: Boolean, isBusy: Boolean, isFaith: Boolean, onToggle: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse), label = "pulse"
    )
    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isActive) Color(0xFF0A2018) else Color(0xFF1A0505)),
        border = BorderStroke(1.dp, if (isActive) Color(0xFF34D399).copy(alpha = 0.5f) else Color(0xFF7F1D1D))) {
        Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(52.dp).scale(if (isActive) pulse else 1f)
                .background(if (isActive) Color(0xFF34D399).copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center) {
                Text(if (isActive) "🤖" else "💤", fontSize = 24.sp)
            }
            Spacer(Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(if (isActive) "AI Secretary চলছে" else "AI Secretary বন্ধ",
                    fontSize = 16.sp, fontWeight = FontWeight.Bold,
                    color = if (isActive) Color(0xFF34D399) else Color(0xFFFCA5A5))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                    if (isBusy) MiniTag2("⏳ Busy", Color(0xFFFCD34D))
                    if (isFaith) MiniTag2("🕌 Faith", Color(0xFF5EEAD4))
                    if (!isBusy && !isFaith && isActive) MiniTag2("✅ Normal", Color(0xFF34D399))
                }
            }
            Switch(checked = isActive, onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(checkedTrackColor = Color(0xFF34D399).copy(alpha = 0.7f), uncheckedTrackColor = Color(0xFF3F1010)))
        }
    }
}

@Composable private fun MiniTag2(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(4.dp), color = color.copy(alpha = 0.1f)) {
        Text(text, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp, color = color)
    }
}

@Composable private fun QuickBtn(emoji: String, label: String, isOn: Boolean, color: Color, onClick: () -> Unit, modifier: Modifier) {
    Card(modifier = modifier.clickable { onClick() }, shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (isOn) color.copy(alpha = 0.12f) else Color(0xFF111827)),
        border = BorderStroke(1.dp, if (isOn) color.copy(alpha = 0.5f) else Color(0xFF1E2D45))) {
        Column(modifier = Modifier.padding(12.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 20.sp)
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = if (isOn) color else Color(0xFF64748B))
            Text(if (isOn) "ON" else "OFF", fontSize = 10.sp, color = if (isOn) color else Color(0xFF334155))
        }
    }
}

@Composable private fun StatCard2(emoji: String, value: String, label: String, color: Color, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
        border = BorderStroke(1.dp, Color(0xFF1E2D45))) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 16.sp)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, fontSize = 10.sp, color = Color(0xFF475569))
        }
    }
}

@Composable private fun DashSectionLabel(text: String) {
    Text(text = text, fontSize = 10.sp, color = Color(0xFF64748B), fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
}
