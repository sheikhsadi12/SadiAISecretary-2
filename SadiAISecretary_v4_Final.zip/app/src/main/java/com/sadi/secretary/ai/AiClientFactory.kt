package com.sadi.secretary.ai

// ╔══════════════════════════════════════════════════════════════╗
// ║      SADI AI SECRETARY — AiClientFactory.kt                  ║
// ║      Phase 02 · Provider Selection + Key Management          ║
// ║                                                              ║
// ║  AiClientFactory  → selected provider এর client দেয়          ║
// ║  AiSettingsManager → API keys secure store/load করে          ║
// ╚══════════════════════════════════════════════════════════════╝

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// DataStore extension
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sadi_settings")

// ══════════════════════════════════════════════════════════════
// AI SETTINGS MANAGER
// API keys + selected provider store/load করে
// ══════════════════════════════════════════════════════════════
@Singleton
class AiSettingsManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    // DataStore keys
    private val KEY_SELECTED_PROVIDER = stringPreferencesKey("selected_provider")

    // ── Encrypted SharedPreferences for API keys ───────────────
    // API keys sensitive data — AES-256 encrypted
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val encryptedPrefs = EncryptedSharedPreferences.create(
        context,
        "sadi_api_keys",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    // ── Selected Provider ──────────────────────────────────────
    val selectedProvider: Flow<AiProvider> = context.dataStore.data.map { prefs ->
        val name = prefs[KEY_SELECTED_PROVIDER] ?: AiProvider.CLAUDE.name
        try { AiProvider.valueOf(name) } catch (e: Exception) { AiProvider.CLAUDE }
    }

    suspend fun setSelectedProvider(provider: AiProvider) {
        context.dataStore.edit { it[KEY_SELECTED_PROVIDER] = provider.name }
    }

    // ── API Key Store/Load ─────────────────────────────────────
    fun saveApiKey(provider: AiProvider, key: String) {
        encryptedPrefs.edit().putString("key_${provider.name}", key).apply()
    }

    fun getApiKey(provider: AiProvider): String {
        return encryptedPrefs.getString("key_${provider.name}", "") ?: ""
    }

    fun hasApiKey(provider: AiProvider): Boolean {
        return getApiKey(provider).isNotBlank()
    }

    // সব providers এর key status
    fun getAllKeyStatus(): Map<AiProvider, Boolean> {
        return AiProvider.values().associateWith { hasApiKey(it) }
    }
}

// ══════════════════════════════════════════════════════════════
// AI CLIENT FACTORY
// Selected provider এর সঠিক client instance দেয়
// ══════════════════════════════════════════════════════════════
@Singleton
class AiClientFactory @Inject constructor(
    private val settingsManager: AiSettingsManager
) {
    // Currently active provider এর client
    fun getClient(provider: AiProvider): BaseAiClient {
        val key = settingsManager.getApiKey(provider)
        return when (provider) {
            AiProvider.CLAUDE -> ClaudeClient(key)
            AiProvider.GEMINI -> GeminiClient(key)
            AiProvider.OPENAI -> OpenAiClient(key)
            AiProvider.GROQ   -> GroqClient(key)
        }
    }

    // Fallback system: primary fail হলে backup try করবে
    // তুমি settings এ priority set করতে পারবে
    suspend fun getActiveClient(): BaseAiClient {
        val provider = settingsManager.selectedProvider.first()
        return getClient(provider)
    }
}
