package com.sadi.secretary.di

// ╔══════════════════════════════════════════════════════════════╗
// ║         SADI AI SECRETARY — DatabaseModule.kt                ║
// ║         Phase 00 · Dependency Injection (Hilt)               ║
// ║                                                              ║
// ║  Room Database কে Hilt দিয়ে inject করা                       ║
// ║  যেকোনো class এ @Inject দিয়ে DB পাওয়া যাবে                  ║
// ╚══════════════════════════════════════════════════════════════╝

import android.content.Context
import androidx.room.Room
import com.sadi.secretary.SadiApp
import com.sadi.secretary.data.db.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    // ──────────────────────────────────────────────────────────
    // Room Database provide করা
    // App জুড়ে একটাই instance (Singleton)
    // ──────────────────────────────────────────────────────────
    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            SadiApp.DB_NAME
        )
            .fallbackToDestructiveMigration()   // dev phase এ ok
            .build()
    }

    // ──────────────────────────────────────────────────────────
    // DAOs provide করা
    // ──────────────────────────────────────────────────────────
    @Provides
    fun provideMessageDao(db: AppDatabase): MessageDao = db.messageDao()

    @Provides
    fun provideContactDao(db: AppDatabase): ContactDao = db.contactDao()

    @Provides
    fun provideMemoryDao(db: AppDatabase): MemoryDao = db.memoryDao()

    @Provides
    fun provideReplyQueueDao(db: AppDatabase): ReplyQueueDao = db.replyQueueDao()
}
