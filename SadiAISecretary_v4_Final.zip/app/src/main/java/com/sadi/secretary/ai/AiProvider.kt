package com.sadi.secretary.ai

// ╔══════════════════════════════════════════════════════════════╗
// ║         SADI AI SECRETARY — AiProvider.kt                    ║
// ║         Phase 02 · Multi-Provider Abstraction Layer          ║
// ║                                                              ║
// ║  SUPPORTED:                                                  ║
// ║    → Claude  (Anthropic)  — Best Bangla context              ║
// ║    → Gemini  (Google)     — Fast + free tier                 ║
// ║    → OpenAI  (GPT-4o)     — Popular + reliable               ║
// ║    → Groq    (LLaMA-3)    — Ultrafast + Free 🔥              ║
// ║                                                              ║
// ║  HOW TO ADD NEW PROVIDER:                                    ║
// ║    1. AiProvider enum এ নাম add করো                          ║
// ║    2. নতুন class বানাও : BaseAiClient implement করো          ║
// ║    3. AiClientFactory তে add করো                             ║
// ║    → বাকি সব code unchanged থাকবে ✅                         ║
// ╚══════════════════════════════════════════════════════════════╝

// ══════════════════════════════════════════════════════════════
// ENUM — সব supported providers
// ══════════════════════════════════════════════════════════════
enum class AiProvider(
    val displayName: String,
    val defaultModel: String,
    val isFree: Boolean
) {
    CLAUDE(
        displayName  = "Claude (Anthropic)",
        defaultModel = "claude-sonnet-4-5",
        isFree       = false
    ),
    GEMINI(
        displayName  = "Gemini (Google)",
        defaultModel = "gemini-1.5-flash",
        isFree       = true   // free tier আছে
    ),
    OPENAI(
        displayName  = "OpenAI (GPT-4o)",
        defaultModel = "gpt-4o-mini",
        isFree       = false
    ),
    GROQ(
        displayName  = "Groq (LLaMA-3)",
        defaultModel = "llama-3.1-8b-instant",
        isFree       = true   // generous free tier
    )
}

// ══════════════════════════════════════════════════════════════
// DATA CLASSES
// ══════════════════════════════════════════════════════════════

data class AiMessage(
    val role: String,    // "user" বা "assistant" বা "system"
    val content: String
)

data class AiRequest(
    val systemPrompt: String,
    val messages: List<AiMessage>,
    val maxTokens: Int = 300,
    val temperature: Double = 0.8
)

data class AiResponse(
    val text: String,
    val provider: AiProvider,
    val isSuccess: Boolean,
    val error: String? = null
)

// ══════════════════════════════════════════════════════════════
// BASE INTERFACE — সব provider এই interface follow করবে
// ══════════════════════════════════════════════════════════════
interface BaseAiClient {
    val provider: AiProvider
    suspend fun generate(request: AiRequest): AiResponse
    fun isConfigured(): Boolean  // API key set আছে কিনা
}
