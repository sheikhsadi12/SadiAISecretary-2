package com.sadi.secretary.services

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.sadi.secretary.data.db.ReplyQueueEntity
import kotlinx.coroutines.*
import kotlin.random.Random

// Note: No @AndroidEntryPoint - AccessibilityService not supported by Hilt directly
class SadiAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    companion object {
        private const val TAG = "SadiAutoSend"
        var instance: SadiAccessibilityService? = null
            private set

        private val MESSENGER_COMPOSE_IDS = listOf(
            "com.facebook.orca:id/composer_input",
            "com.facebook.orca:id/message_edit_text"
        )
        private val MESSENGER_SEND_IDS = listOf(
            "com.facebook.orca:id/send_button",
            "com.facebook.orca:id/action_button"
        )
        private val TELEGRAM_COMPOSE_IDS = listOf(
            "org.telegram.messenger:id/chatActivityEnterView",
            "org.telegram.messenger:id/message_text"
        )
        private val TELEGRAM_SEND_IDS = listOf(
            "org.telegram.messenger:id/chat_compose_button",
            "org.telegram.messenger:id/send_button"
        )
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "✅ Accessibility Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {}
    override fun onInterrupt() { Log.w(TAG, "Accessibility Service interrupted") }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        scope.cancel()
    }

    fun sendMessage(reply: ReplyQueueEntity, onComplete: (Boolean) -> Unit) {
        scope.launch {
            try {
                val opened = openApp(reply.contactApp)
                if (!opened) { onComplete(false); return@launch }
                delay(2000)
                val textBox = findTextBox(reply.contactApp)
                if (textBox == null) { onComplete(false); return@launch }
                textBox.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                delay(500)
                typeText(textBox, reply.aiReply)
                delay(300)
                val sent = clickSend(reply.contactApp)
                onComplete(sent)
            } catch (e: Exception) {
                Log.e(TAG, "Auto-send error: ${e.message}")
                onComplete(false)
            }
        }
    }

    private fun openApp(app: String): Boolean {
        return try {
            val pkg = when (app) { "messenger" -> "com.facebook.orca"; "telegram" -> "org.telegram.messenger"; else -> return false }
            val intent = packageManager.getLaunchIntentForPackage(pkg) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            true
        } catch (e: Exception) { false }
    }

    private suspend fun findTextBox(app: String): AccessibilityNodeInfo? {
        val ids = when (app) { "messenger" -> MESSENGER_COMPOSE_IDS; "telegram" -> TELEGRAM_COMPOSE_IDS; else -> emptyList() }
        repeat(5) {
            val root = rootInActiveWindow ?: return@repeat
            for (id in ids) {
                val nodes = root.findAccessibilityNodeInfosByViewId(id)
                if (nodes.isNotEmpty()) return nodes[0]
            }
            delay(800)
        }
        return null
    }

    private suspend fun typeText(node: AccessibilityNodeInfo, text: String) {
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        delay((text.length * 60L).coerceIn(500, 3000))
    }

    private suspend fun clickSend(app: String): Boolean {
        val ids = when (app) { "messenger" -> MESSENGER_SEND_IDS; "telegram" -> TELEGRAM_SEND_IDS; else -> emptyList() }
        repeat(3) {
            val root = rootInActiveWindow ?: return@repeat
            for (id in ids) {
                val nodes = root.findAccessibilityNodeInfosByViewId(id)
                if (nodes.isNotEmpty()) { nodes[0].performAction(AccessibilityNodeInfo.ACTION_CLICK); return true }
            }
            delay(500)
        }
        return false
    }
}
