package com.sadi.secretary.services

import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.sadi.secretary.SadiApp
import com.sadi.secretary.data.db.MessageEntity
import com.sadi.secretary.data.repository.MessageRepository
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import dagger.hilt.EntryPoint
import kotlinx.coroutines.*

// Hilt EntryPoint for NotificationListenerService
@EntryPoint
@dagger.hilt.InstallIn(SingletonComponent::class)
interface NotificationListenerEntryPoint {
    fun messageRepository(): MessageRepository
    fun replyEngine(): ReplyEngine
}

class SadiNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var repository: MessageRepository? = null
    private var replyEngine: ReplyEngine? = null

    companion object {
        private const val TAG = "SadiMsgCapture"
        const val PKG_MESSENGER = "com.facebook.orca"
        const val PKG_TELEGRAM  = "org.telegram.messenger"
        private const val EXTRA_TITLE = "android.title"
        private const val EXTRA_TEXT  = "android.text"
        private const val EXTRA_SUMMARY = "android.summaryText"
        private val SKIP_TEXTS = setOf("missed call", "voice call", "video call", "is calling", "GIF", "Sticker")
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        // Initialize Hilt dependencies via EntryPoint
        try {
            val entryPoint = EntryPointAccessors.fromApplication(
                applicationContext, NotificationListenerEntryPoint::class.java
            )
            repository = entryPoint.messageRepository()
            replyEngine = entryPoint.replyEngine()
            Log.d(TAG, "✅ Notification Listener connected")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to init dependencies: ${e.message}")
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        requestRebind(componentName)
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName
        if (pkg !in SadiApp.SUPPORTED_APPS) return
        if (sbn.isOngoing) return

        val extras = sbn.notification.extras ?: return
        val parsed = when (pkg) {
            PKG_MESSENGER -> parseMessenger(extras, sbn)
            PKG_TELEGRAM  -> parseTelegram(extras, sbn)
            else -> null
        } ?: return

        if (SKIP_TEXTS.any { parsed.messageText.contains(it, ignoreCase = true) }) return
        if (parsed.messageText.isBlank()) return

        Log.d(TAG, "📩 ${parsed.senderName}: ${parsed.messageText}")

        scope.launch {
            try {
                val repo = repository ?: return@launch
                val engine = replyEngine ?: return@launch
                val id = repo.saveMessage(parsed)
                engine.processMessage(parsed.copy(id = id))
            } catch (e: Exception) {
                Log.e(TAG, "Error processing message: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }

    private fun parseMessenger(extras: android.os.Bundle, sbn: StatusBarNotification): MessageEntity? {
        return try {
            val title   = extras.getCharSequence(EXTRA_TITLE)?.toString() ?: return null
            val text    = extras.getCharSequence(EXTRA_TEXT)?.toString() ?: return null
            val summary = extras.getCharSequence(EXTRA_SUMMARY)?.toString()
            val isGroup = summary != null
            val senderName = if (isGroup) text.substringBefore(":").trim().takeIf { it.isNotBlank() } ?: title else title
            val messageText = if (isGroup) text.substringAfter(":").trim() else text
            MessageEntity(senderName = senderName, senderApp = "messenger", messageText = messageText,
                isGroup = isGroup, groupName = if (isGroup) title else null, timestamp = sbn.postTime, packageName = PKG_MESSENGER)
        } catch (e: Exception) { null }
    }

    private fun parseTelegram(extras: android.os.Bundle, sbn: StatusBarNotification): MessageEntity? {
        return try {
            val title = extras.getCharSequence(EXTRA_TITLE)?.toString() ?: return null
            val text  = extras.getCharSequence(EXTRA_TEXT)?.toString() ?: return null
            val isGroup = text.contains(": ") && !text.startsWith("@")
            val senderName = if (isGroup) text.substringBefore(":").trim() else title
            val messageText = if (isGroup) text.substringAfter(":").trim() else text
            if (messageText in listOf("Photo", "Sticker", "GIF")) return null
            MessageEntity(senderName = senderName, senderApp = "telegram", messageText = messageText,
                isGroup = isGroup, groupName = if (isGroup) title else null, timestamp = sbn.postTime, packageName = PKG_TELEGRAM)
        } catch (e: Exception) { null }
    }
}
