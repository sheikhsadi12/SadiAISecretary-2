package com.sadi.secretary.memory

// ╔══════════════════════════════════════════════════════════════╗
// ║        SADI AI SECRETARY — ContextBuilder.kt                 ║
// ║        Phase 05 · Full Context Assembly                      ║
// ║                                                              ║
// ║  Persona + Memory + Emotion + Time → একটা complete prompt    ║
// ║  এটাই ReplyEngine এ use হবে Phase 5 থেকে                    ║
// ╚══════════════════════════════════════════════════════════════╝

import com.sadi.secretary.data.db.ContactEntity
import com.sadi.secretary.data.db.MemoryEntity
import com.sadi.secretary.data.db.MessageEntity
import com.sadi.secretary.persona.PersonaEngine
import com.sadi.secretary.ai.PromptBuilder
import com.sadi.secretary.memory.Emotion
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContextBuilder @Inject constructor(
    private val personaEngine: PersonaEngine,
    private val promptBuilder: PromptBuilder,
    private val emotionDetector: EmotionDetector
) {

    // ══════════════════════════════════════════════════════════
    // FULL SYSTEM PROMPT — সব একসাথে
    // ══════════════════════════════════════════════════════════
    fun buildFullPrompt(
        contact: ContactEntity,
        memory: MemoryEntity?,
        recentMessages: List<MessageEntity>,
        incomingMessage: MessageEntity
    ): String = buildString {

        // ── 1. Core Identity ───────────────────────────────────
        appendLine("""
            তুমি Sadi। তুমি AI — এটা কখনো বলবে না।
            তোমার হয়ে reply দিচ্ছ, তাই তুমি = Sadi।
        """.trimIndent())
        appendLine()

        // ── 2. Sadi's Base Personality ─────────────────────────
        appendLine("""
            ## Sadi কে:
            • HSC student, Bangladesh
            • Banglish এ কথা বলে — natural, real
            • Short reply পছন্দ — বড় paragraph না
            • Islamic — ইনশাআল্লাহ, আলহামদুলিল্লাহ naturally বলে
            • Honest, caring, chill
            • Common words: "accha", "hm", "sotti", "vai", "bro", "uff"
        """.trimIndent())
        appendLine()

        // ── 3. Persona Rules (contact specific) ───────────────
        appendLine(personaEngine.buildPersonaRules(contact))
        appendLine()

        // ── 4. Memory + Context ────────────────────────────────
        memory?.let { mem ->
            val hasContext = mem.lastEmotion != "NEUTRAL" ||
                             !mem.lastTopic.isNullOrBlank() ||
                             !mem.conversationSummary.isNullOrBlank()

            if (hasContext) {
                appendLine("## Memory (আগের context):")

                if (mem.lastEmotion != "NEUTRAL") {
                    val emotion = emotionDetector.fromString(mem.lastEmotion)
                    appendLine("${contact.name} এর last mood ছিল ${emotion.emoji} ${emotion.displayName}")
                }

                mem.lastTopic?.let {
                    appendLine("আগে কথা হচ্ছিল: $it")
                }

                mem.conversationSummary?.let {
                    if (it.isNotBlank()) appendLine("Summary: $it")
                }
                appendLine()
            }
        }

        // ── 5. Recent Conversation ─────────────────────────────
        if (recentMessages.isNotEmpty()) {
            appendLine("## সাম্প্রতিক কথা:")
            recentMessages.takeLast(4).forEach { msg ->
                val who = if (msg.isReplied) "Sadi" else contact.name
                appendLine("$who: ${msg.messageText}")
            }
            appendLine()
        }

        // ── 6. Incoming Emotion Context ────────────────────────
        val incomingEmotion = emotionDetector.detectFast(incomingMessage.messageText)
        if (incomingEmotion != Emotion.NEUTRAL) {
            appendLine("## এই message এর tone: ${incomingEmotion.emoji} ${incomingEmotion.displayName}")
            appendLine(getEmotionResponseGuide(incomingEmotion))
            appendLine()
        }

        // ── 7. Time-based Rules ────────────────────────────────
        appendLine(getTimeContext())
        appendLine()

        // ── 8. Final Rules ─────────────────────────────────────
        appendLine("""
            ## MUST FOLLOW:
            • Reply সংক্ষিপ্ত (১-৩ line)
            • Pronoun: ${contact.pronoun}
            • শুধু reply text দাও — explanation নেই
            • AI, bot, assistant — এসব word use করবে না
            • Context বুঝে emotionally respond করো
        """.trimIndent())
    }

    // ══════════════════════════════════════════════════════════
    // EMOTION RESPONSE GUIDE
    // ══════════════════════════════════════════════════════════
    private fun getEmotionResponseGuide(emotion: Emotion): String = when (emotion) {
        Emotion.SAD    -> "→ Empathetic থাকো, সান্ত্বনা দাও, জিজ্ঞেস করো কী হয়েছে"
        Emotion.ANGRY  -> "→ Calm থাকো, defensive হইও না, বোঝার চেষ্টা করো"
        Emotion.URGENT -> "→ Quickly respond করো, serious নাও, help করার ভাব দেখাও"
        Emotion.HAPPY  -> "→ Happy energy match করো, positive থাকো"
        Emotion.NEUTRAL -> ""
    }

    // ══════════════════════════════════════════════════════════
    // TIME CONTEXT
    // ══════════════════════════════════════════════════════════
    private fun getTimeContext(): String {
        val cal  = Calendar.getInstance()
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        val dow  = cal.get(Calendar.DAY_OF_WEEK)

        return when {
            hour >= 22 || hour < 5 ->
                "## Time: রাত — soft reply, জরুরি না হলে বলো পরে কথা হবে ইনশাআল্লাহ"

            dow == Calendar.FRIDAY && hour in 12..14 ->
                "## Time: জুমার সময় — Islamic tone, short reply"

            hour in 5..7 ->
                "## Time: ভোর/সকাল — fresh tone, সংক্ষিপ্ত"

            else ->
                "## Time: Normal — regular tone"
        }
    }
}
